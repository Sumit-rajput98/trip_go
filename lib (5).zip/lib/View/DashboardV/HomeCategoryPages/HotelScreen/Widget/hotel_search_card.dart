import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/Widget/city_search_page.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/Widget/room_guest_selector_page.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/TourScreen/TourWidget/custom_calender_dialog.dart';
import '../../../../Widgets/gradient_button.dart';
import 'package:trip_go/constants.dart';

class HotelSearchCard extends StatefulWidget {
  const HotelSearchCard({super.key});

  @override
  State<HotelSearchCard> createState() => _HotelSearchCardState();
}

class _HotelSearchCardState extends State<HotelSearchCard> {
  final TextEditingController checkInController = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  final TextEditingController checkOutController = TextEditingController();

  int totalGuests = 2;
  int roomCount = 1;

  String? checkInDay;
  String? checkOutDay;
  
  bool enabled=false;

  @override
  void initState() {
    super.initState();
    final today = DateTime.now();
    checkInDay = DateFormat('MM/dd/yyyy').format(today);
    checkInController.text = checkInDay!;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 10),
        Material(
          elevation: 4,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [Color(0xFFFFEBEE), Color(0xFFFFF5F6)],
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// City Picker
                GestureDetector(
                  onTap: () async {
                    final selectedCity = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CitySearchPage(),
                      ),
                    );
                    if (selectedCity != null) {
                      setState(() {
                        cityController.text = selectedCity;
                      });
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Enter City name, Location or Specific hotel',
                          style: TextStyle(fontSize: 12, fontFamily: 'poppins'),
                        ),
                        const SizedBox(height: 4),
                        AbsorbPointer(
                          child: TextFormField(
                            controller: cityController,
                            readOnly: true,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'poppins',
                            ),
                            decoration: const InputDecoration(
                              hintText: 'Enter City/Hotel Name',
                              hintStyle: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'poppins',
                              ),
                              border: InputBorder.none,
                              isDense: true,
                              contentPadding: EdgeInsets.zero,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                /// Date Picker Row
                Row(
                  children: [
                    /// Check-in
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final selectedDate = await showDialog<DateTime>(
                            context: context,
                            builder: (context) => const CustomCalendarDialog(),
                          );
                          if (selectedDate != null) {
                            setState(() {
                              checkInDay = DateFormat('MM/dd/yyyy').format(selectedDate);
                              checkInController.text = checkInDay!;
                              checkOutDay = null;
                              checkOutController.clear();
                            });
                          }
                        },
                        child: _buildDateFieldTile(
                          title: 'CHECK-IN',
                          date: checkInDay,
                          enabled: true,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),

                    /// Check-out
                    Expanded(
                      child: GestureDetector(
                        onTap: (checkInDay != null)
                            ? () async {
                                final selectedDate = await showDialog<DateTime>(
                                  context: context,
                                  builder: (context) => const CustomCalendarDialog(),
                                );
                                if (selectedDate != null) {
                                  setState(() {
                                    checkOutDay = DateFormat('MM/dd/yyyy').format(selectedDate);
                                    checkOutController.text = checkOutDay!;
                                    enabled = true;
                                  });
                                }
                              }
                            : null,
                        child: _buildDateFieldTile(
                          title: 'CHECK-OUT',
                          date: checkOutDay,
                          enabled: enabled,
                          onClear: () {
                            setState(() {
                              checkOutDay = null;
                              checkOutController.clear();
                              enabled = false;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                /// Guest & Room Picker
                GestureDetector(
                  onTap: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const RoomGuestSelectorPage(),
                      ),
                    );
                    if (result != null) {
                      setState(() {
                        totalGuests = result['totalGuests'];
                        roomCount = result['rooms'];
                      });
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Guest and Room",
                                style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: 'poppins',
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "$totalGuests Guest${totalGuests > 1 ? 's' : ''}, $roomCount Room${roomCount > 1 ? 's' : ''}",
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  fontFamily: 'poppins',
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.add_circle_outline,
                          color: Colors.black54,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                /// Search Button
                SizedBox(
                  width: double.infinity,
                  child: GradientButton(label: 'SEARCH', onPressed: () {}),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDateFieldTile({
    required String title,
    required String? date,
    required bool enabled,
    VoidCallback? onClear,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      decoration: BoxDecoration(
        color: enabled ? Colors.white : Colors.grey.shade100,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: enabled ? Colors.black87 : Colors.grey,
              fontFamily: 'poppins',
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.calendar_today, size: 16, color: Colors.black54),
                  const SizedBox(width: 6),
                  Text(
                    date ?? " ",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'poppins',
                      color: enabled ? Colors.black : Colors.grey,
                    ),
                  ),
                ],
              ),
              if (date != null && onClear != null)
                InkWell(
                  onTap: onClear,
                  child: const CircleAvatar(
                    radius: 12,
                    backgroundColor: Colors.grey,
                    child: Icon(Icons.close, size: 14, color: Colors.white),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
