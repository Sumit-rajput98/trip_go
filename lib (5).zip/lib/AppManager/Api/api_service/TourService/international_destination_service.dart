import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../../../Model/TourM/international_destination_model.dart';

class InternationalDestinationService {
  static const String url =
      'https://admin.travelsdata.com/api/HolidayPackages/InternationalDestinations';

  static Future<List<InternationalDestinationModel>> fetchDestinations() async {
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      final List data = jsonData['data'];
      return data
          .map((item) => InternationalDestinationModel.fromJson(item))
          .toList();
    } else {
      throw Exception('Failed to load international destinations');
    }
  }
}