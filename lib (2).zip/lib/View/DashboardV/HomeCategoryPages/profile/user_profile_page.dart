import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/profile/profile_page.dart';
import 'package:trip_go/constants.dart';
import 'edit_profile.dart';

class UserProfilePage extends StatefulWidget {
  const UserProfilePage({super.key});

  @override
  State<UserProfilePage> createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  String? title, firstName, lastName, email, phone;

  final List<Map<String, String>> listItems = [
    {
      "title": "Edit Profile",
      "img": "https://cdn-icons-png.flaticon.com/512/1077/1077063.png",
    },
    {
      "title": "My Settings",
      "img": "https://cdn-icons-png.flaticon.com/512/2099/2099058.png",
    },
    {
      "title": "Share the App",
      "img": "https://cdn-icons-png.flaticon.com/512/929/929610.png",
    },
    {
      "title": "Rate Us",
      "img": "https://cdn-icons-png.flaticon.com/512/1828/1828884.png",
    },
    {
      "title": "About TripGo",
      "img": "https://cdn-icons-png.flaticon.com/512/942/942748.png",
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      title = prefs.getString('title')?.trim();
      firstName = prefs.getString('firstName')?.trim();
      lastName = prefs.getString('lastName')?.trim();
      email = prefs.getString('email')?.trim();
      phone = prefs.getString('phone')?.trim();
    });
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Confirm Logout"),
        content: const Text("Are you sure you want to logout?"),
        actions: [
          TextButton(
            child: const Text("Cancel"),
            onPressed: () => Navigator.pop(context, false),
          ),
          TextButton(
            child: const Text("Logout", style: TextStyle(color: Colors.red)),
            onPressed: () => Navigator.pop(context, true),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const ProfilePage()),
        (route) => false,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Logged out successfully")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final fullName = [
      if (title != null && title!.isNotEmpty) title,
      if (firstName != null) firstName,
      if (lastName != null) lastName
    ].where((e) => e != null && e!.isNotEmpty).join(" ");

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: constants.ultraLightThemeColor1,
        title: const Text('Account', style: TextStyle(fontFamily: 'poppins')),
        centerTitle: true,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        children: [
          const SizedBox(height: 20),
          Card(
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            color: Colors.white,
            shadowColor: Colors.grey.shade200,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 30,
                    backgroundImage: NetworkImage(
                      'https://cdn-icons-png.flaticon.com/512/3135/3135715.png',
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Hi,", style: TextStyle(fontSize: 14, fontFamily: 'poppins')),
                        Text(
                          fullName,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'poppins',
                          ),
                        ),
                        if (email != null && email!.isNotEmpty)
                          Text(email!, style: const TextStyle(fontSize: 14, fontFamily: 'poppins')),
                        if (phone != null && phone!.isNotEmpty)
                          Text(phone!, style: const TextStyle(fontSize: 14, fontFamily: 'poppins')),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 30),
          ...listItems.map((item) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: listTileWidget(
                title: item["title"]!,
                img: item["img"]!,
                onTap: () {
                  if (item["title"] == "Edit Profile") {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const EditProfilePage()),
                    );
                  }
                },
              ),
            );
          }),
          const SizedBox(height: 10),
          listTileWidget(
            title: "Logout",
            img: "https://cdn-icons-png.flaticon.com/512/1828/1828479.png",
            onTap: _logout,
          ),
        ],
      ),
    );
  }
}

class listTileWidget extends StatelessWidget {
  final String title;
  final String img;
  final VoidCallback? onTap;

  const listTileWidget({
    super.key,
    required this.title,
    required this.img,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      tileColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      leading: Image.network(img, height: 20),
      title: Text(title, style: constants.titleStyle),
      trailing: const Icon(Icons.arrow_forward_ios, size: 20),
    );
  }
}
