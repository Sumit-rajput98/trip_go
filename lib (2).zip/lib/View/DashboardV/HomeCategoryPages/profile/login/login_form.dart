import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/profile/auth_provider.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/profile/user_profile_page.dart';
import 'package:trip_go/ViewM/AccountVM/login_otp_view_model.dart';
import 'package:trip_go/ViewM/AccountVM/register_view_model.dart';
import 'package:trip_go/constants.dart';

class LoginForm extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController loginController;
  final VoidCallback onSuccess;
  final VoidCallback? onLoginComplete;

  const LoginForm({
    super.key,
    required this.formKey,
    required this.loginController,
    required this.onSuccess, this.onLoginComplete,
  });

  @override
  Widget build(BuildContext context) {
    final loginOtpVM = Provider.of<LoginOtpViewModel>(context);
    final registerVM = Provider.of<RegisterViewModel>(context);

    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Login or Create an account',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Poppins',
            ),
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: loginController,
            style: const TextStyle(fontFamily: 'Poppins'),
            decoration: InputDecoration(
              hintText: 'Enter your Email Id/Mobile no.',
              prefixIcon: const Icon(Icons.email_outlined),
              hintStyle: const TextStyle(fontFamily: 'Poppins'),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'This field cannot be empty';
              }
              final emailRegex = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
              final phoneRegex = RegExp(r'^[0-9]{10,13}$');
              if (!emailRegex.hasMatch(value) && !phoneRegex.hasMatch(value)) {
                return 'Enter valid Email or Mobile Number';
              }
              return null;
            },
          ),
          const SizedBox(height: 20),
          (loginOtpVM.isLoading || registerVM.isLoading)
              ? const Center(child: CircularProgressIndicator())
              : GestureDetector(
                  onTap: () async {
                    if (formKey.currentState!.validate()) {
                      final input = loginController.text.trim();
                      const countryCode = "91";

                      final emailRegex = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
                      final phoneRegex = RegExp(r'^[0-9]{10,13}$');

                      try {
                        // Try login with OTP first
                        await loginOtpVM.loginWithOtp({
                          "CountryCode":countryCode,
                           "PhoneNumber": input
                        });
                          /* {
                          phoneRegex.hasMatch(input)
                              ? "PhoneNumber"
                              : "Email": input,
                          if (phoneRegex.hasMatch(input)) "CountryCode": countryCode
                        } */
                        if (loginOtpVM.otpResponse?.success == true) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                loginOtpVM.otpResponse?.message ??
                                    "Otp sent successfully",
                              ),
                            ),
                          );
                          onSuccess(); 
                        } else {
                          // Try Register
                          dynamic registerBody = phoneRegex.hasMatch(input)
                              ? {
                                  "CountryCode": countryCode,
                                  "PhoneNumber": input,
                                }
                              : {
                                  "Email": input,
                                };

                          await registerVM.registerUser(registerBody);

                          if (registerVM.registerResponse?.success == true) {
                            final user = registerVM.registerResponse?.data;

                            final prefs = await SharedPreferences.getInstance();
                            await prefs.setBool('isLoggedIn', true);
                            Provider.of<AuthProvider>(context, listen: false).login();
                            await prefs.setInt('userId', user?.id ?? 0);
                            await prefs.setString('phone', user?.phone ?? '');
                            // optionally set email if available
                            if (user?.email != null) {
                              await prefs.setString('email', user?.email ?? '');
                            }

                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(registerVM.registerResponse?.message ?? "User Registered")),
                            );

                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const UserProfilePage(),
                              ),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  registerVM.registerResponse?.message ??
                                      "Registration failed",
                                ),
                              ),
                            );
                          }
                        }
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text("Something went wrong")),
                        );
                      }
                    }
                  },
                  child: Container(
                    height: 50,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [constants.themeColor1, constants.themeColor2],
                      ),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Center(
                      child: Text(
                        'CONTINUE',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}
