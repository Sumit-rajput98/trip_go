import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class WallatPage extends StatefulWidget {
  const WallatPage({super.key});

  @override
  State<WallatPage> createState() => _WallatPageState();
}

class _WallatPageState extends State<WallatPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
      child: Text(
  'Wallet Page',
  style: GoogleFonts.poppins(
    fontSize: 16,
    fontWeight: FontWeight.w500,
    color: Colors.black,
  ),
)
,
    ),);
  }
}