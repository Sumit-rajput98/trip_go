import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:trip_go/Model/HotelM/hotel_search_model.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/hotel_promo_section.dart';
import 'package:trip_go/ViewM/HotelVM/hotel_booking_view_model.dart';
import 'package:trip_go/constants.dart';
import '../../../../Model/HotelM/hotel_detail_data.dart';
import '../../../../Model/HotelM/hotek_booking_model.dart';

class HotelReviewScreen extends StatefulWidget {
  final String hid;
  final String batchKey;
  final List<RoomDetail> rooma;
  final Hotel1 hotel;
  final String city;
  final String cin;
  final String cout;
  final String room;
  final String pax;
  final int totalGuests;

  const HotelReviewScreen({
    super.key,
    required this.hotel,
    required this.city,
    required this.cin,
    required this.cout,
    required this.room,
    required this.pax,
    required this.totalGuests,
    required this.hid,
    required this.batchKey,
    required this.rooma,
  });

  @override
  State<HotelReviewScreen> createState() => _HotelReviewScreenState();
}

class _HotelReviewScreenState extends State<HotelReviewScreen> {
  @override
  void initState() {
    super.initState();
    _initBooking();
  }

  void _initBooking() {
    Future.delayed(Duration.zero, () {
      final bookingCode = widget.rooma.isNotEmpty ? widget.rooma.first.bookingCode : null;
      final request = {
        "BookingCode": bookingCode,
        "hid": widget.hid,
        "BatchKey": widget.batchKey,
        "Rooms": widget.rooma.map((e) => e.toJson()).toList(),
      };
      Provider.of<HotelBookingViewModel>(context, listen: false).bookHotel(request);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Consumer<HotelBookingViewModel>(
        builder: (context, bookingVM, _) {
          if (bookingVM.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          
          if (bookingVM.bookingResult == null) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  bookingVM.errorMessage ?? "Failed to load booking details",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(fontSize: 16),
                ),
              ),
            );
          }
          
          return _HotelReviewContent(
            hotel: widget.hotel,
            bookingModel: bookingVM.bookingResult!,
            cin: widget.cin,
            cout: widget.cout,
            totalGuests: widget.totalGuests,
            roomCount: widget.room,
          );
        },
      ),
    );
  }
}

class _HotelReviewContent extends StatelessWidget {
  final Hotel1 hotel;
  final HotelBookingModel bookingModel;
  final String cin;
  final String cout;
  final int totalGuests;
  final String roomCount;

  const _HotelReviewContent({
    required this.hotel,
    required this.bookingModel,
    required this.cin,
    required this.cout,
    required this.totalGuests,
    required this.roomCount,
  });

  @override
  Widget build(BuildContext context) {
    final room = _getFirstRoom();
    if (room == null) {
      return const Center(child: Text("No room details available"));
    }

    return SingleChildScrollView(
      child: Column(
        children: [
          _buildHeader(context),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _HotelCard(hotel: hotel, cin: cin, cout: cout, totalGuests: totalGuests, roomCount: roomCount),
                const SizedBox(height: 16),
                _PriceBreakupCard(room: room),
                const SizedBox(height: 16),
                const HotelPromoSection(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Room? _getFirstRoom() {
    final roomList = bookingModel.data?.dataRooms;
    if (roomList == null || roomList.isEmpty) return null;
    return roomList.first;
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 130,
      decoration: const BoxDecoration(
        color: Color(0xFF341f97),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 36),
      alignment: Alignment.topLeft,
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: const Icon(Icons.arrow_back, color: Colors.white),
          ),
          const SizedBox(width: 16),
          Text("Hotel Review",
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              )),
        ],
      ),
    );
  }
}

class _HotelCard extends StatelessWidget {
  final Hotel1 hotel;
  final String cin;
  final String cout;
  final int totalGuests;
  final String roomCount;

  const _HotelCard({
    required this.hotel,
    required this.cin,
    required this.cout,
    required this.totalGuests,
    required this.roomCount,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _boxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      hotel.name ?? 'Hotel Name',
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.location_on_outlined, size: 14, color: Colors.grey),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            hotel.address ?? 'Address not available',
                            style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[700]),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  hotel.images ?? 'https://via.placeholder.com/60',
                  height: 60,
                  width: 60,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: Colors.grey[200],
                    height: 60,
                    width: 60,
                    child: const Icon(Icons.hotel, color: Colors.grey),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            "Check-In: $cin | Check-Out: $cout",
            style: GoogleFonts.poppins(fontSize: 13),
          ),
          const SizedBox(height: 4),
          Text(
            "Guests: $totalGuests | Rooms: $roomCount",
            style: GoogleFonts.poppins(fontSize: 13),
          ),
        ],
      ),
    );
  }

  BoxDecoration _boxDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.grey[300]!),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 6,
          offset: const Offset(0, 2),
        ),
      ],
    );
  }
}

class _PriceBreakupCard extends StatelessWidget {
  final Room room;

  const _PriceBreakupCard({required this.room});

  @override
  Widget build(BuildContext context) {
    final roomRate = (room.totalFare ?? 0) - (room.totalTax ?? 0);
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ]
        ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Price Summary",
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600,
              fontSize: 16,
            ),
          ),
          const Divider(height: 20),
          _buildPriceRow("Room Rate", roomRate),
          const SizedBox(height: 8),
          _buildPriceRow("Taxes & Fees", room.totalTax),
          const Divider(height: 24),
          _buildPriceRow("Total Amount", room.totalFare, isTotal: true),
        ],
      ),
    );
  }

  Widget _buildPriceRow(String title, double? amount, {bool isTotal = false}) {
    final formattedAmount = amount != null 
      ? "₹ ${amount.toStringAsFixed(2)}"
      : "₹ --";
    
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 14,
            fontWeight: isTotal ? FontWeight.w600 : FontWeight.w400,
            color: isTotal ? const Color(0xFF341f97) : Colors.black87,
          ),
        ),
        Text(
          formattedAmount,
          style: GoogleFonts.poppins(
            fontWeight: isTotal ? FontWeight.w700 : FontWeight.w500,
            fontSize: isTotal ? 16 : 14,
            color: isTotal ? const Color(0xFF341f97) : Colors.black87,
          ),
        ),
      ],
    );
  }
}