import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/Filters/amenities_bottom_sheet.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/Filters/hotel_filter_bottom_sheet.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/Filters/price_filter_bottom-sheet.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/Filters/ratings_filter_bottom_sheet.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/Filters/sort_by_bottom_sheet.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/HotelDetail/hotel_detail_page.dart';
import 'package:trip_go/View/Widgets/custom_app_bar.dart';
import 'package:trip_go/View/Widgets/gradient_button.dart';
import 'package:trip_go/ViewM/HotelVM/hotel_search_view_model.dart';

class HotelSearchResultPage extends StatefulWidget {
  final String city;
  final String cin;
  final String cout;
  final String rooms;
  final String pax;
  final int totalGuests;
  const HotelSearchResultPage({
    super.key,
    required this.city,
    required this.cin,
    required this.cout,
    required this.rooms,
    required this.pax,
    required this.totalGuests,
  });

  @override
  State<HotelSearchResultPage> createState() => _HotelSearchResultPageState();
}

class _HotelSearchResultPageState extends State<HotelSearchResultPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _fetchData());
  }

  Future<void> _fetchData() async {
    final vm = Provider.of<HotelSearchViewModel>(context, listen: false);
    await vm.searchHotels({
      "city": widget.city,
      "Rooms": widget.rooms,
      "cin": widget.cin,
      "cOut": widget.cout,
      "pax": widget.pax,
    });
  }

  int _calculateNights(String cin, String cout) {
    try {
      final checkIn = DateFormat("yyyy-MM-dd").parse(cin);
      final checkOut = DateFormat("yyyy-MM-dd").parse(cout);
      return checkOut.difference(checkIn).inDays;
    } catch (_) {
      return 1;
    }
  }

  @override
  Widget build(BuildContext context) {
    final nights = _calculateNights(widget.cin, widget.cout);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(title: "Hotel Search Result"),
      bottomNavigationBar: _buildBottomFilterBar(context),
      body: Consumer<HotelSearchViewModel>(
        builder: (context, vm, _) {
          return Column(
            children: [
              _buildTopBar(),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _fetchData,
                  child: vm.isLoading
                      ? _buildShimmerList()
                      : vm.filteredHotels.isEmpty
                          ? ListView(
                              physics: const AlwaysScrollableScrollPhysics(),
                              children: [
                                const SizedBox(height: 100),
                                Center(
                                  child: Text(
                                    "No data found",
                                    style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                              ],
                            )
                          : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 16),
                    itemCount: vm.filteredHotels.length + 1,
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return _buildHotelCount(vm);
                      }

                      final hotel = vm.filteredHotels[index - 1];
                      final room = hotel.rooms?.isNotEmpty == true ? hotel.rooms?.first : null;

                      // ✅ Safe check for getHotelsData length
                      final data = (index - 1 < vm.getHotelsData.length)
                          ? vm.getHotelsData[index - 1]
                          : null;

                      return Padding(
                        padding: const EdgeInsets.all(12),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade300,
                                blurRadius: 6,
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                                child: Image.network(
                                  hotel.images ?? 'https://via.placeholder.com/600x400?text=No+Image',
                                  height: 180,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    height: 180,
                                    color: Colors.grey[200],
                                    child: const Icon(Icons.hotel, size: 50),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      hotel.name ?? "Hotel",
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        const Icon(Icons.location_on, size: 14, color: Colors.grey),
                                        const SizedBox(width: 4),
                                        Expanded(
                                          child: Text(
                                            hotel.address ?? '',
                                            style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600]),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        if (room?.mealType != null && room!.mealType!.isNotEmpty)
                                          _tag(room.mealType!, Colors.blue),
                                        _tag(
                                          room?.isRefundable == true ? "Refundable" : "Non-Refundable",
                                          room?.isRefundable == true ? Colors.green : Colors.red,
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    if (room?.name != null && room!.name!.isNotEmpty)
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                        decoration: BoxDecoration(
                                          color: Colors.grey[100],
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: Text(
                                          room.name!.join(", "),
                                          style: GoogleFonts.poppins(fontSize: 12, color: Colors.black87),
                                        ),
                                      ),
                                    const SizedBox(height: 10),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(children: _buildStars(hotel.starRating)),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            if (room?.totalFare != null && room?.totalTax != null)
                                              Text(
                                                "₹${(room!.totalFare! + room.totalTax!).toStringAsFixed(2)}",
                                                style: GoogleFonts.poppins(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.black,
                                                ),
                                              ),
                                            Text(
                                              "for $nights nights",
                                              style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 12),
                                    Container(
                                      width: double.infinity,
                                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                      decoration: BoxDecoration(
                                        color: Colors.red.shade100,
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Text(
                                        "TRIPGOHOTELS Discount Applied",
                                        style: GoogleFonts.poppins(color: Colors.red, fontSize: 12),
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    GradientButton(
                                      label: "View Room",
                                      onPressed: () {
                                        final vm = Provider.of<HotelSearchViewModel>(context, listen: false);
                                        final batchKey = vm.searchResult?.data?.batchKey ?? ''; // ✅ Correct access

                                        final rooms = hotel.rooms ?? [];

                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => HotelDetailPage(
                                              rooms: rooms,
                                              hid: hotel.hotelCode.toString(),
                                              batchKey: batchKey, city: widget.city, cin: widget.cin, cout: widget.cout, room: widget.rooms, pax: widget.pax, totalGuests: widget.totalGuests, // ✅ Now correctly passed
                                            ),
                                          ),
                                        );
                                      },
                                    ),

                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // _buildTopBar, _buildHotelCount, _buildStars, _tag, _buildShimmerList, _buildBottomFilterBar remain unchanged


  Widget _buildTopBar() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: const BoxDecoration(color: Color(0xFF1B499F)),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "${widget.city.toUpperCase()} | ${DateFormat('MMM dd').format(DateFormat('yyyy-MM-dd').parse(widget.cin))} ",
                style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 14),
              ),
              Row(
                children: [
                  const Icon(Icons.person, size: 14, color: Colors.white),
                  const SizedBox(width: 4),
                  Text("${widget.totalGuests} Guest",
                      style: GoogleFonts.poppins(color: Colors.white, fontSize: 12)),
                ],
              )
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)),
            child: Text("CHANGE",
                style: GoogleFonts.poppins(color: const Color(0xFF1B499F), fontWeight: FontWeight.bold, fontSize: 12)),
          ),
        ],
      ),
    );
  }

  Widget _buildHotelCount(HotelSearchViewModel vm) {
    final count = vm.searchResult?.data?.hotels?.length ?? 0;
    return Container(
      margin: const EdgeInsets.only(top: 6, bottom: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.grey.shade300, blurRadius: 4)],
      ),
      child: Text(
        "$count Hotels Available",
        style: GoogleFonts.poppins(fontWeight: FontWeight.w500, fontSize: 14),
      ),
    );
  }

  List<Widget> _buildStars(String? rating) {
    final filled = int.tryParse(rating?.split(".").first ?? "0") ?? 0;
    return List.generate(5, (index) {
      return Icon(Icons.star, size: 16, color: index < filled ? Colors.orange : Colors.grey.shade300);
    });
  }

  Widget _tag(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(4)),
      child: Text(label, style: GoogleFonts.poppins(fontSize: 11, color: color, fontWeight: FontWeight.w500)),
    );
  }

  Widget _buildShimmerList() {
    return ListView.builder(
      itemCount: 3,
      padding: const EdgeInsets.all(12),
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: Colors.grey.shade300,
        highlightColor: Colors.grey.shade100,
        child: Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Container(height: 180, width: double.infinity, color: Colors.white),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(height: 16, width: 150, color: Colors.white),
                    const SizedBox(height: 8),
                    Container(height: 14, width: 200, color: Colors.white),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Container(height: 20, width: 80, color: Colors.white),
                        const SizedBox(width: 10),
                        Container(height: 20, width: 100, color: Colors.white),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Container(height: 20, width: double.infinity, color: Colors.white),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(height: 16, width: 80, color: Colors.white),
                        Container(height: 16, width: 60, color: Colors.white),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(height: 30, width: double.infinity, color: Colors.white),
                    const SizedBox(height: 12),
                    Container(height: 40, width: double.infinity, color: Colors.white),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomFilterBar(BuildContext context) {
    final List<Map<String, dynamic>> filters = [
      {"icon": Icons.filter_list, "label": "Filter", "onTap": (){}},
     {"icon": Icons.star, "label": "Rating", "onTap": () async {
  final result = await showModalBottomSheet<int>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => const RatingFilterBottomSheet(),
  );

  if (result != null) {
    Provider.of<HotelSearchViewModel>(context, listen: false).filterByRating(result);
  }
}},
{"icon": Icons.attach_money, "label": "Price", "onTap": () async {
  final result = await showModalBottomSheet<String?>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => const PriceFilterBottomSheet(),
  );

  if (result != null) {
    Provider.of<HotelSearchViewModel>(context, listen: false).filterByPriceRange(result);
  }
}},


      
      {"icon": Icons.widgets, "label": "Amenities", "onTap": (){}},
      {"icon": Icons.sort, "label": "Sort", "onTap": () async {
  final result = await showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (_) => const SortByBottomSheet(),
  );

  if (result != null) {
    Provider.of<HotelSearchViewModel>(context, listen: false).sortHotels(result);
  }
}},

    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.grey.shade300, blurRadius: 5)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: filters.map((item) {
          return Expanded(
            child: GestureDetector(
              onTap: item['onTap'] as VoidCallback,
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(item['icon'], size: 18, color: Colors.black87),
                    const SizedBox(height: 4),
                    Text(
                      item['label'],
                      style: GoogleFonts.poppins(fontSize: 11, color: Colors.black87),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

}