

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:trip_go/View/Widgets/Drawer/custom_drawer.dart';
import '../widgets/cab_app_bar.dart';

class CabResultScreen extends StatelessWidget {
  const CabResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CabAppBar(
        title: 'Delhi to NOIDA',
        subline: "Thursday, 10 July, 2025 08:30 AM",
        onBack: () => Navigator.pop(context),
        onSearchTap: () {},
        onEditTap: () async {},

      ),
      body: Column(
        children: [
          _buildTopInfo(),
          Expanded(
            child: ListView(
              children: [
                _buildCabTile(
                  image: 'https://transfer.easemytrip.com/assets/img/dezire.png', // Replace with your image
                  name: 'Dzire, Etios\nor equivalent',
                  price: 879,
                  discount: 74,
                ),
                _buildCabTile(
                  image: 'https://transfer.easemytrip.com/assets/img/wagonr.png', // Replace with your image
                  name: 'Swift, Celerio\nor equivalent',
                  price: 891,
                  discount: 94,
                ),
                _buildCabTile(
                  image: 'https://transfer.easemytrip.com/assets/img/xylo.png', // Replace with your image
                  name: 'Wagon R\nor Equivalent',
                  price: 905,
                  discount: 60,
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          children: [
            _buildBottomButton(Icons.filter_alt, "Filter"),
            _buildBottomButton(Icons.sort, "Sort"),
          ],
        ),
      ),
    );
  }

  Widget _buildTopInfo() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Colors.white, Color(0xFFFFEBEE), Color(0xFFFFF5F6)],
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: const [
          _InfoIcon(text: "Save up to 30%", icon: CupertinoIcons.hand_thumbsup,),
          _InfoIcon(text: "Professional Drivers", icon: CupertinoIcons.person),
          _InfoIcon(text: "24*7 Support", icon: Icons.chat_bubble_outline),
        ],
      ),
    );
  }

  Widget _buildCabTile({
    required String image,
    required String name,
    required int price,
    required int discount,
  }) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.all(10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Image.network(image, width: 85, height: 60, fit: BoxFit.contain),
                const SizedBox(width: 5),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'poppins')),
                    const SizedBox(height: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildInfoBox(Icons.directions_car, "1 Unit"),
                            SizedBox(width: 5),
                            _buildInfoBox(Icons.airline_seat_recline_extra, "4 Seat"),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildInfoBox(Icons.luggage, "1 Luggage"),
                            SizedBox(width: 5),
                            _buildInfoBox(Icons.location_on, "26 Km"),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text("₹ $price", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'poppins')),
                    Row(
                      children: [
                        const Icon(Icons.check_circle, color: Colors.green, size: 16),
                        const SizedBox(width: 5),
                        const Text("TGOCAB Applied", style: TextStyle(color: Colors.green)),
                      ],
                    ),
                    Text("Book Now and Get Rs $discount OFF", style: TextStyle(color: constants.themeColor1, fontFamily: 'poppins', fontSize: 13)),
                  ],
                )
              ],
            ),
            const SizedBox(height: 8),
            Divider(),
            const SizedBox(height: 8),
            Row(
              children: [
                _buildTag("Safety standards", Icons.shield),
                const SizedBox(width: 10),
                _buildTag("Partial Payment", Icons.payment),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildTag(String text, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        border: Border.all(color: constants.themeColor1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, size: 14, color: constants.themeColor1),
          const SizedBox(width: 5),
          Text(text, style: TextStyle(fontSize: 12, color: constants.themeColor1, fontFamily: 'poppins')),
        ],
      ),
    );
  }

  Widget _buildBottomButton(IconData icon, String label) {
    return Expanded(
      child: InkWell(
        onTap: () {},
        child: Container(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, ),
              Text(label),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _buildInfoBox(IconData icon, String text) {
  return Container(
    width: 110, // fix equal width to align rows uniformly
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Icon(icon, size: 16, color: Colors.black87),
        const SizedBox(width: 5),
        Flexible(
          child: Text(
            text,
            style: const TextStyle(fontSize: 13, fontFamily: 'poppins'),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    ),
  );
}


class _InfoIcon extends StatelessWidget {
  final String text;
  final IconData icon;

  const _InfoIcon({required this.text, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: constants.themeColor1),
        const SizedBox(height: 4),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontFamily: 'poppins',)),
      ],
    );
  }
}
//