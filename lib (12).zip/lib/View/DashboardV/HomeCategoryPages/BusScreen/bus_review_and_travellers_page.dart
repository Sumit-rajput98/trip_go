import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/FlightScreen/FlightWidgets/gst_bottom_sheet.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/hotel_promo_section.dart';
import 'package:trip_go/constants.dart';

class BusReviewAndTravellerPage extends StatefulWidget {
  const BusReviewAndTravellerPage({super.key});

  @override
  State<BusReviewAndTravellerPage> createState() =>
      _BusReviewAndTravellerPageState();
}

class _BusReviewAndTravellerPageState extends State<BusReviewAndTravellerPage> {
  bool? isInsuranceSelected; // null by default, or use `true` for preselection

   bool isChecked = false;
  bool isCheckedGst = false;
  String? errorMessage;
  String? companyName;
  String? regNo;
 Widget buildContactInfoSection() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // Title
      Text(
        "Contact Information",
        style: GoogleFonts.poppins(
          fontWeight: FontWeight.w600,
          fontSize: 16,
        ),
      ),
      const SizedBox(height: 12),

      // Email & Mobile Card
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Email Field
            Text("Email ID", style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500)),
            const SizedBox(height: 8),
            TextFormField(
              decoration: InputDecoration(
                hintText: "Enter Email ID",
                hintStyle: GoogleFonts.poppins(fontSize: 13, color: Colors.grey),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Mobile Number
            Text("Mobile No", style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500)),
            const SizedBox(height: 8),
            Row(
              children: [
                Container(
                  width: 64,
                  height: 48,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.grey.shade100,
                  ),
                  child: Text(
                    "+91",
                    style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextFormField(
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      hintText: "Enter Mobile Number",
                      hintStyle: GoogleFonts.poppins(fontSize: 13),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      const SizedBox(height: 16),

      // WhatsApp Notification Banner
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF1FFF5),
          border: Border.all(color: constants.themeColor1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Container(
              width: 28,
              height: 28,
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
              child: Image.network(
                "https://e7.pngegg.com/pngimages/447/479/png-clipart-whatsapp-computer-icons-whatsapp-text-whatsapp-icon-thumbnail.png",
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) => const Icon(CupertinoIcons.chat_bubble, size: 20, color: Colors.green),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text.rich(
                TextSpan(
                  text: "Get Booking Details & Updates on ",
                  style: GoogleFonts.poppins(fontSize: 13),
                  children: [
                    TextSpan(
                      text: "WhatsApp",
                      style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                border: Border.all(color: constants.themeColor1, width: 2),
              ),
              child: const Icon(Icons.check, size: 12, color: Colors.blue),
            ),
          ],
        ),
      ),
    ],
  );
}

Widget buildInsuranceSection() {
  return Container(
    padding: const EdgeInsets.all(16),
    margin: const EdgeInsets.only(top: 12),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(14),
      color: constants.themeColor1.withOpacity(0.04),
      border: Border.all(color: constants.themeColor1.withOpacity(0.2)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.verified_user, color: constants.themeColor1),
            const SizedBox(width: 8),
            const Text(
              "Travel Insurance",
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const Spacer(),
            Image.network(
              'https://flight.easemytrip.com/Content/img/acko-logo.png',
              height: 28,
            ),
          ],
        ),
        const SizedBox(height: 8),
        const Divider(height: 20),
        const Text(
          "Secure your trip with ACKO Travel Insurance at just ₹199/- per traveller",
          style: TextStyle(fontSize: 13),
        ),
        const SizedBox(height: 6),
        const Text("View T&C", style: TextStyle(color: Colors.blue, fontSize: 13)),
        const SizedBox(height: 10),
        Column(
          children: [
            RadioListTile<bool>(
              value: true,
              groupValue: isInsuranceSelected,
              activeColor: constants.themeColor1,
              onChanged: (value) {
                setState(() {
                  isInsuranceSelected = value;
                });
              },
              title: const Text("Yes, Secure My Trip"),
              subtitle: const Text(
                "More than 36% of our customers choose to secure their trip.",
                style: TextStyle(fontSize: 12),
              ),
            ),
            RadioListTile<bool>(
              value: false,
              groupValue: isInsuranceSelected,
              activeColor: constants.themeColor1,
              onChanged: (value) {
                setState(() {
                  isInsuranceSelected = value;
                });
              },
              title: const Text("I am willing to risk my trip"),
            ),
          ],
        ),
      ],
    ),
  );
}
 
  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 130,
      decoration: BoxDecoration(
        color: constants.themeColor1,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 36),
      alignment: Alignment.topLeft,
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: const Icon(Icons.arrow_back, color: Colors.white),
          ),
          const SizedBox(width: 16),
          Text(
            "Bus Review",
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildGstSection() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
        border: Border.all(color: Colors.grey.withOpacity(.4)),
      ),
      child: Row(
        children: [
          Checkbox(
            value: isCheckedGst,
            onChanged: (val) async {
              setState(() {
                isCheckedGst = val!;
              });
              if (val == true) {
                final result = await showModalBottomSheet<Map<String, String>>(
                  context: context,
                  isScrollControlled: true,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(5),
                    ),
                  ),
                  builder:
                      (context) => const Padding(
                        padding: EdgeInsets.only(
                          bottom: 20,
                          top: 20,
                          left: 16,
                          right: 16,
                        ),
                        child: GstBottomSheet(),
                      ),
                );
                if (result != null) {
                  companyName = result['companyName'];
                  regNo = result['registrationNo'];
                }
              }
            },
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Use GST for this booking (OPTIONAL)",
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  "To claim credit of GST charged by hotels/TripGo, please enter your company's GST number.",
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTermsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
      child: Row(
        children: [
          Checkbox(
            value: isChecked,
            onChanged: (val) {
              setState(() {
                isChecked = val!;
              });
            },
          ),
          RichText(
            text: TextSpan(
              style: GoogleFonts.poppins(color: Colors.black),
              children: [
                const TextSpan(text: "I Accept "),
                TextSpan(
                  text: "T&C ",
                  style: const TextStyle(color: Colors.blue),
                ),
                const TextSpan(text: "and "),
                TextSpan(
                  text: "Privacy Policy",
                  style: const TextStyle(color: Colors.blue),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }



  bool showDetails = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
       body: SingleChildScrollView(
       
        child: Stack(

          children: [
           _buildHeader(context),

            Padding(
              padding: const EdgeInsets.fromLTRB(16,90,16,20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // BUS DETAIL CARD
                  _buildBusDetailCard(),
                  const SizedBox(height: 16),
                  // TRAVELLER DETAILS
                  Text(
                    "Travellar Details",
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 6, bottom: 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: constants.themeColor1.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: constants.themeColor1),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.info_outline,
                          size: 18,
                          color: constants.themeColor1,
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            'Name should be same as in Government ID proof',
                            style: GoogleFonts.poppins(
                              fontSize: 13,
                              color: Colors.deepPurple.shade900,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  TravellerDetailCard(index: 1, seat: "L1 (SL)"),
                  const SizedBox(height: 12),
                  TravellerDetailCard(index: 2, seat: "L5 (SL)"),
                  const SizedBox(height: 12),
                  buildInsuranceSection(),
                  const SizedBox(height: 12),
                  buildContactInfoSection(),
                  const SizedBox(height: 12),
                  HotelPromoSection(),
                  const SizedBox(height: 12),
                  _buildGstSection(),
                  const SizedBox(height: 12),
                  _buildTermsSection()
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCircle() {
    return Container(
      width: 10,
      height: 10,
      decoration: const BoxDecoration(
        color: Colors.black,
        shape: BoxShape.circle,
      ),
    );
  }

  Widget _buildDashedLine({double height = 140}) {
    return Container(
      height: height,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(10, (_) {
          return Container(width: 2, height: 4, color: Colors.grey.shade400);
        }),
      ),
    );
  }

  Widget _buildBusDetailCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title and Date
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Bengaluru To Mumbai',
                    style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
                  ),
                  Text(
                    'Sat, Jul 05, 2025',
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
              IconButton(
                icon: Icon(showDetails ? Icons.expand_less : Icons.expand_more),
                onPressed: () => setState(() => showDetails = !showDetails),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Boarding/Dropping Time & Address section (gray background)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Boarding/Dropping Time & Address",
                  style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 12),

                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Boarding column
                    Expanded(
                      flex: 4,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Bengaluru",
                            style: GoogleFonts.poppins(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "2:15 PM",
                            style: GoogleFonts.poppins(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "Marathahalli, Near HDFC Bank, beside",
                            style: GoogleFonts.poppins(
                              fontSize: 12,
                              height: 1.3,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Duration and dot
                    Expanded(
                      flex: 3,
                      child: Column(
                        children: [
                          Text(
                            '17h 00m',
                            style: GoogleFonts.poppins(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                          const SizedBox(height: 4),
                           Icon(
                            Icons.fiber_manual_record,
                            size: 8,
                            color: constants.themeColor2,
                          ),
                        ],
                      ),
                    ),

                    // Dropping column
                    Expanded(
                      flex: 4,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            "Mumbai",
                            style: GoogleFonts.poppins(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "7:35 AM",
                            style: GoogleFonts.poppins(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "CBD Belapur - Fly Over Bridge End",
                            textAlign: TextAlign.right,
                            style: GoogleFonts.poppins(
                              fontSize: 12,
                              height: 1.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                if (showDetails) ...[
                  const SizedBox(height: 20),

                  // Pick up & Drop section with circle and dotted line
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Timeline (aligned with pickup and drop only)
                      Column(
                        children: [
                          _buildCircle(),
                          _buildDashedLine(height: 100),
                          _buildCircle(),
                        ],
                      ),
                      const SizedBox(width: 12),
                      // Pickup and Drop content
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Pick up",
                              style: GoogleFonts.poppins(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Marathahalli, Near HDFC Bank, beside kalanikethan towards silk board. & 2:15 PM",
                              style: GoogleFonts.poppins(fontSize: 13),
                            ),
                            const SizedBox(height: 14),
                            Text(
                              "Drop Point",
                              style: GoogleFonts.poppins(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "CBD Belapur - Fly Over Bridge End Towards Nerul & 7:35 AM",
                              style: GoogleFonts.poppins(fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          if (showDetails) ...[
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              decoration: BoxDecoration(
                color: constants.themeColor1.withOpacity(0.05),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: constants.themeColor1.withOpacity(0.3),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildInfoRow(
                    Icons.directions_bus,
                    "Bus Operator",
                    "Orange Tours and Travels",
                  ),
                  const SizedBox(height: 14),
                  _buildInfoRow(Icons.event_seat, "Selected Seats", "L1 | L5"),
                  const SizedBox(height: 14),
                  _buildInfoRow(
                    Icons.directions,
                    "Bus Type",
                    "2 + 1 (42) PLATINUM VOLVO MULTI AXLE SLEEPER, AC, LED",
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: constants.themeColor1, size: 20),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.poppins(fontSize: 13, color: Colors.black54),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class TravellerDetailCard extends StatefulWidget {
  final int index;
  final String seat;

  const TravellerDetailCard({
    super.key,
    required this.index,
    required this.seat,
  });

  @override
  State<TravellerDetailCard> createState() => _TravellerDetailCardState();
}

class _TravellerDetailCardState extends State<TravellerDetailCard> {
  String selectedGender = "";

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "ADULT ${widget.index}",
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  widget.seat,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: constants.themeColor2,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Gender Selection
          Row(
            children: [
              Expanded(child: _genderButton("Male")),
              const SizedBox(width: 12),
              Expanded(child: _genderButton("Female")),
            ],
          ),

          const SizedBox(height: 10),

          // Name Fields
          _labelledTextField(
            "First Name (& Middle name if any)",
            "Enter First Name",
          ),
          const SizedBox(height: 10),

          Row(
            children: [
              Expanded(
                child: _labelledTextField("Last Name", "Enter Last Name"),
              ),
              const SizedBox(width: 12),
              Expanded(child: _labelledTextField("Age", "Enter Age")),
            ],
          ),
        ],
      ),
    );
  }

  Widget _genderButton(String text) {
    final bool isSelected = selectedGender == text;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedGender = text;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color:
              isSelected
                  ? constants.themeColor1.withOpacity(0.1)
                  : Colors.transparent,
          border: Border.all(
            color: isSelected ? constants.themeColor1 : Colors.grey.shade300,
          ),
          borderRadius: BorderRadius.circular(10),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: GoogleFonts.poppins(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: isSelected ? constants.themeColor1 : Colors.black54,
          ),
        ),
      ),
    );
  }

  Widget _labelledTextField(String label, String hint) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: GoogleFonts.poppins(fontSize: 13)),
        const SizedBox(height: 6),
        TextField(
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: GoogleFonts.poppins(fontSize: 13),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
          ),
        ),
      ],
    );
  }
}
