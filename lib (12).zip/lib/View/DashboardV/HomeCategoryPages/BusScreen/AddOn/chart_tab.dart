// seat_provider.dart
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:trip_go/constants.dart';

class SeatProvider extends ChangeNotifier {
  final Set<String> _selectedSeats = {};

  Set<String> get selectedSeats => _selectedSeats;

  void toggleSeat(String seatId) {
    if (_selectedSeats.contains(seatId)) {
      _selectedSeats.remove(seatId);
    } else {
      _selectedSeats.add(seatId);
    }
    notifyListeners();
  }

  bool isSelected(String seatId) => _selectedSeats.contains(seatId);
}


// chart_tab.dart


class ChartTab extends StatelessWidget {
  const ChartTab({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          const SizedBox(height: 8),
          Padding(
  padding: const EdgeInsets.symmetric(horizontal: 16),
  child: Container(
    height: 46, // Increase if still cutting
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: constants.themeColor1),
    ),
    child: TabBar(
      dividerHeight: 0,
      labelColor: Colors.black,
      unselectedLabelColor: Colors.black54,
      labelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w600),
      unselectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w500),
      indicator: BoxDecoration(
        color: constants.themeColor1.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: constants.themeColor1),
      ),
      indicatorPadding: const EdgeInsets.all(4), // Controls box spacing inside
      indicatorSize: TabBarIndicatorSize.tab,
      tabs: const [
        Tab(text: 'LOWER SEAT'),
        Tab(text: 'UPPER SEAT'),
      ],
    ),
  ),
),
const SizedBox(height: 10),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SeatIndicator(color: Colors.pinkAccent, label: "Ladies"),
                SeatIndicator(color: Colors.green, label: "Selected"),
                SeatIndicator(color: Colors.white, border: true, label: "Available"),
                SeatIndicator(color: Colors.grey, label: "Booked"),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: TabBarView(
              children: [
                SeatLayout(
                  title: 'Lower Seat',
                  leftSeats: ['6', '12', '18', '24', '30', '36', '42'],
                  rightSeats: ['4', '9', '16', '22', '28', '34', '40'],
                  windowSeats: ['W3', 'W10', 'W15', 'W21', 'W27', 'W33', 'W39'],
                ),
                SeatLayout(
                  title: 'Upper Seat',
                  leftSeats: ['5', '11', '17', '23', '29', '35', '41'],
                  rightSeats: ['2', '8', '14', '20', '26', '32', '38'],
                  windowSeats: ['W1', 'W7', 'W13', 'W19', 'W25', 'W31', 'W37'],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SeatIndicator extends StatelessWidget {
  final Color color;
  final String label;
  final bool border;
  const SeatIndicator({super.key, required this.color, required this.label, this.border = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            border: border ? Border.all(color: Colors.black26) : null,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 4),
        Text(label, style: GoogleFonts.poppins(fontSize: 12)),
      ],
    );
  }
}
class SeatLayout extends StatelessWidget {
  final String title;
  final List<String> leftSeats;
  final List<String> rightSeats;
  final List<String> windowSeats;

  SeatLayout({
    super.key,
    required this.title,
    required this.leftSeats,
    required this.rightSeats,
    required this.windowSeats,
  });

  final Set<String> bookedSeats = {
    '6', '4', 'W3', '12', '9', 'W10', '18', '16', 'W15', '24', '22', 'W21',
    '5', 'W1', 'W7', '11', '17', 'W13', '23', '29', 'W19',
  };

  @override
  Widget build(BuildContext context) {
    final seatProvider = Provider.of<SeatProvider>(context);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Heading container with grey background
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    title,
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      color: Colors.black87,
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Centered seat rows
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        children: leftSeats
                            .map((id) => _seatBox(context, id, seatProvider))
                            .toList(),
                      ),
                      const SizedBox(width: 20), // Reduced gap between col 1 & 2
                      Column(
                        children: List.generate(
                          windowSeats.length,
                          (i) => Row(
                            children: [
                              _seatBox(context, rightSeats[i], seatProvider),
                              const SizedBox(width: 8),
                              _seatBox(context, windowSeats[i], seatProvider),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _seatBox(BuildContext context, String id, SeatProvider provider) {
    final isBooked = bookedSeats.contains(id);
    final isSelected = provider.isSelected(id);

    Color bgColor = Colors.white;
    Color borderColor = Colors.grey.shade400;
    Color textColor = Colors.black;

    if (isBooked) {
      bgColor = Colors.grey.shade400;
      textColor = Colors.white;
    } else if (isSelected) {
      bgColor = Colors.green;
      textColor = Colors.white;
    }

    return GestureDetector(
      onTap: isBooked
          ? null
          : () {
              provider.toggleSeat(id);
            },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        width: 50,
        height: 60,
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: borderColor),
        ),
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(id, style: GoogleFonts.poppins(color: textColor, fontSize: 13)),
            if (!isBooked)
              Text('₹1100', style: GoogleFonts.poppins(fontSize: 11, color: textColor)),
          ],
        ),
      ),
    );
  }
}
