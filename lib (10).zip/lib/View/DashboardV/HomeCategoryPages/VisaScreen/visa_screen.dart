import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_email_sender/flutter_email_sender.dart';
import 'package:google_fonts/google_fonts.dart';

class VisaScreen extends StatefulWidget {
  const VisaScreen({super.key});

  @override
  State<VisaScreen> createState() => _VisaScreenState();
}

class _VisaScreenState extends State<VisaScreen> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final subjectController = TextEditingController();
  final messageController = TextEditingController();

  Future<void> _sendEmail() async {
    final Email email = Email(
      body:
          "New Visa Enquiry:\n\nName: ${nameController.text}\nEmail: ${emailController.text}\nPhone: ${phoneController.text}\nSubject: ${subjectController.text}\n\nMessage:\n${messageController.text}",
      subject: subjectController.text.isNotEmpty
          ? subjectController.text
          : "Visa Enquiry",
      recipients: ['sumitrajput96938@gmail.com'], // Replace with your support email
      isHTML: false,
    );

    try {
      await FlutterEmailSender.send(email);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your enquiry has been submitted!')),
      );

      // Optional: clear fields
      nameController.clear();
      emailController.clear();
      phoneController.clear();
      subjectController.clear();
      messageController.clear();
    } catch (error) {
      print(error);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send email: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context).size;

    return Scaffold(
      body: Stack(
        children: [
          // Blurred background image
          SizedBox(
            height: media.height,
            width: media.width,
            child: ImageFiltered(
              imageFilter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
              child: Image.network(
                "https://tripgoonline.com/static/media/insurance-img.6a5b9aa4922bf177f0fc.jpeg",
                fit: BoxFit.cover,
              ),
            ),
          ),

          Container(
            height: media.height,
            width: media.width,
            color: Colors.black.withOpacity(0.2),
          ),

          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Get in touch!",
                    style: GoogleFonts.poppins(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    "Don't hesitate to get in touch with us - we're happy to talk to you!",
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      color: Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 20),

                  _buildContactCard(
                    icon: Icons.call_outlined,
                    title: "CALL US 24*7",
                    detail: "+91 92112 52358",
                  ),
                  const SizedBox(height: 12),
                  _buildContactCard(
                    icon: Icons.mail_outline,
                    title: "MAKE A QUOTE",
                    detail: "support@tripgoonline.com",
                  ),
                  const SizedBox(height: 12),
                  _buildContactCard(
                    icon: Icons.location_on_outlined,
                    title: "WORK STATION",
                    detail:
                        "1815, Tower 4, DLF Corporate Greens,\nSector 74A, Gurugram - 122004",
                  ),
                  const SizedBox(height: 30),

                  // Enquiry Form
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        )
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Send an Enquiry",
                            style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            )),
                        const SizedBox(height: 15),
                        _buildTextField("Your Name", nameController),
                        _buildTextField("Your Email", emailController),
                        _buildTextField("Your Phone Number", phoneController),
                        _buildTextField("Subject", subjectController),
                        _buildTextField("Your Message", messageController,
                            maxLines: 5),
                        const SizedBox(height: 15),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xff1B499F),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            onPressed: _sendEmail,
                            child: Text(
                              "Submit",
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactCard({
    required IconData icon,
    required String title,
    required String detail,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.85),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, size: 32, color: Colors.black87),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    )),
                const SizedBox(height: 4),
                Text(detail,
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: Colors.black87,
                    )),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildTextField(String hint, TextEditingController controller,
      {int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: GoogleFonts.poppins(fontSize: 13),
          filled: true,
          fillColor: Colors.grey.shade100,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(6),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        ),
      ),
    );
  }
}
