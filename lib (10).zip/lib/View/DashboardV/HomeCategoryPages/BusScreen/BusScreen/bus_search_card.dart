import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/BusScreen/bus_search_view.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/BusScreen/search_bus_city_view.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/FlightScreen/FlightWidgets/calender_screen.dart';
import 'package:trip_go/View/Widgets/gradient_button.dart';
import 'package:trip_go/constants.dart';

class BusSearchCard2 extends StatefulWidget {
  const BusSearchCard2({super.key});

  @override
  State<BusSearchCard2> createState() => _BusSearchCard2State();
}

class _BusSearchCard2State extends State<BusSearchCard2> {
  final TextEditingController fromCityController = TextEditingController();
  final TextEditingController toCityController = TextEditingController();
  DateTime selectedDate = DateTime.now();

  void swapCities() {
    setState(() {
      final temp = fromCityController.text;
      fromCityController.text = toCityController.text;
      toCityController.text = temp;
    });
  }

  void setQuickDate(int daysFromNow) {
    setState(() {
      selectedDate = DateTime.now().add(Duration(days: daysFromNow));
    });
  }
  Future<void> _openCalendar() async {
    final selected = await Navigator.push<DateTime>(
      context,
      MaterialPageRoute(
        builder: (_) => const FullScreenCalendar(isDeparture: true),
      ),
    );
    
    if (selected != null) {
      setState(() {
        selectedDate = selected;
      });
    }
  }
  String get formattedDate => DateFormat('dd-MM-yyyy').format(selectedDate);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [Colors.white, Color(0xFFFFEBEE), Color(0xFFFFF5F6)],
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// FROM field
                _buildCityField("FROM", "Enter City", fromCityController, isFrom: true),
                const SizedBox(height: 16),

                /// TO field
                _buildCityField("TO", "Enter City", toCityController),
                const SizedBox(height: 16),

                /// DEPARTURE DATE FIELD
                GestureDetector(
                  onTap: _openCalendar,
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "DEPARTURE DATE",
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'poppins',
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            const Icon(Icons.calendar_today, size: 16, color: Colors.black54),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                formattedDate,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'poppins',
                                ),
                              ),
                            ),
                            _buildQuickOption("TOMORROW", 1),
                            const SizedBox(width: 8),
                            _buildQuickOption("DAY AFTER", 2),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                /// SEARCH BUTTON
                SizedBox(
                  width: double.infinity,
                  child: GradientButton(label: "Search", onPressed: () {
                      if (fromCityController.text.isEmpty || toCityController.text.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Please fill out all fields")),
                        );
                        return;
                      }

                      // TODO: Navigate to BusResultScreen or call API
                      debugPrint("From: ${fromCityController.text}");
                      debugPrint("To: ${toCityController.text}");
                      debugPrint("Date: $formattedDate");
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BusSearchView(
                            fromCity: fromCityController.text,
                            toCity: toCityController.text,
                            travelDate: selectedDate,
                          ),
                        ),
                      );
                    },
                    )
            )],
            ),
          ),
        ],
      ),
    );
  }
Widget _buildCityField(
  String label,
  String hint,
  TextEditingController controller, {
  bool isFrom = false,
}) {
  return Stack(
    children: [
      GestureDetector(
        onTap: () async {
          final selectedCity = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SearchBusCityView()),
          );
          if (selectedCity != null) {
            setState(() {
              controller.text = selectedCity['city'] ?? '';
            });
          }
        },
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey,
                  fontFamily: 'poppins',
                ),
              ),
              const SizedBox(height: 4),
              Text(
                controller.text.isEmpty ? hint : controller.text,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'poppins',
                  color: controller.text.isEmpty ? Colors.grey : Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),

      /// Swap icon
      if (isFrom)
        Positioned(
          right: 6,
          top: 16,
          child: GestureDetector(
            onTap: swapCities,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                shape: BoxShape.circle,
                color: Colors.white,
              ),
              child: Icon(Icons.swap_vert, size: 16, color: constants.themeColor1),
            ),
          ),
        ),
    ],
  );
}

  Widget _buildQuickOption(String label, int daysFromNow) {
    return GestureDetector(
      onTap: () => setQuickDate(daysFromNow),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          border: Border.all(color: constants.themeColor1),
          borderRadius: BorderRadius.circular(20),
          color: Colors.white,
        ),
        child: Text(
          label,
          style:  TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            fontFamily: 'poppins',
            color: constants.themeColor1,
          ),
        ),
      ),
    );
  }
}
