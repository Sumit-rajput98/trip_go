import 'package:flutter/material.dart';
import 'package:trip_go/constants.dart';

class DealsPage extends StatelessWidget {
  final List<Map<String, String>> deals = [
    {
      "image":
      "https://demoxml.com/html/comre/images/c-img-1.jpg",
      "title": "FLAT 40% OFF HOTEL BOOKINGS IN 10 CITIES NEAR YOU",
      "expiry": "Expires On : Jan 17, 2014"
    },
    {
      "image":
      "https://demoxml.com/html/comre/images/c-img-2.jpg",
      "title": "EXCITING CYCLING DEALS FOR ADVENTURE SEEKERS",
      "expiry": "Expires On : Jan 25, 2025"
    },
    {
      "image":
      "https://demoxml.com/html/comre/images/c-img-3.jpg",
      "title": "Flat 40% off Hotel Bookings In 10 Cities Near you",
      "expiry": "Expires On : Jan 17, 2025"
    },
    {
      "image":
      "https://demoxml.com/html/comre/images/c-img-5.jpg",
      "title": "EXCITING CYCLING DEALS FOR ADVENTURE SEEKERS",
      "expiry": "Expires On : Jan 25, 2025"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 40.0, // Sets the AppBar height to 40 pixels
        centerTitle: false,  // Aligns the title to the start (left)
        titleSpacing: 0,     // Removes default spacing before the title
        leading: IconButton(
          icon: Icon(Icons.arrow_circle_left_outlined, size: 30),
          padding: EdgeInsets.zero, // Eliminates padding around the icon
          constraints: BoxConstraints(), // Removes default constraints
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "All Offers",
          style: TextStyle(
            fontSize: 16.0,
            fontFamily: 'poppins',
            fontWeight: FontWeight.w500,
            color: Colors.black,
          ),
        ),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Center(
            child: Text(
              "GREAT DEALS OF THE DAY",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500, fontFamily: 'poppins'),
            ),
          ),
          SizedBox(height: 16),
          ...deals.map((deal) => DealCard(deal)).toList(),
        ],
      ),
    );
  }
}

class DealCard extends StatelessWidget {
  final Map<String, String> deal;

  DealCard(this.deal);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: EdgeInsets.only(bottom: 20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius:
                BorderRadius.vertical(top: Radius.circular(0)),
                child: Image.network(
                  deal['image']!,
                  width: double.infinity,
                  height: 160,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 10,
                left: 10,
                child: Container(
                  color: Colors.red,
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  child: Text(
                    "EXCLUSIVE",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              Positioned(
                top: 10,
                right: 10,
                child: Icon(Icons.star_border, color: Colors.redAccent),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Text(
              deal['title']!,
              style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'poppins'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(deal['expiry']!, style: TextStyle(fontFamily: 'poppins'),),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 12),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: constants.themeColor1,
                minimumSize: Size(double.infinity, 40),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.zero, // Removes rounded corners
                ),
              ),
              onPressed: () {},
              child: Text(
                "GET COUPON CODE",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontFamily: 'poppins',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}