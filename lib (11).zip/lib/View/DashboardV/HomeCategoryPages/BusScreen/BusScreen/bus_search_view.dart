import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/AddOn/bus_add_on_page.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/BusWidgets/bus_star_sheet_filter.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/bus_review_and_travellers_page.dart';
import '../BusWidgets/BusFilters/bus_price_filter.dart';
import '../BusWidgets/BusFilters/bus_seat_sheet_model.dart';
import '../BusWidgets/BusFilters/bus_sort_filter_sheet.dart';
import '../BusWidgets/bus_app_bar.dart';
import '../BusWidgets/bus_card.dart';
import '../BusWidgets/bus_enums.dart';
import '../BusWidgets/bus_filter_bottom_sheet.dart';
import '../BusWidgets/bus_filter_header.dart';

class BusSearchView extends StatefulWidget {
  final String fromCity;
  final String toCity;
  final DateTime travelDate;

  const BusSearchView({
    super.key,
    required this.fromCity,
    required this.toCity,
    required this.travelDate,
  });

  @override
  State<BusSearchView> createState() => _BusSearchViewState();
}

class _BusSearchViewState extends State<BusSearchView> {
  String formatDate(DateTime date) {
    return DateFormat('E, dd MMM').format(date);
  }
  BusSortType selectedSortType = BusSortType.departure;
  SortOrder sortOrder = SortOrder.ascending;
  @override
  Widget build(BuildContext context) {
    final filters = ["6pm-12am", "AC", "Non-AC"];
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: BusAppBar(
        title: "${widget.fromCity} - ${widget.toCity}",
        subline: formatDate(widget.travelDate),
        onBack: () => Navigator.pop(context),
        onSearchTap: (){},
        onEditTap: (){},
      ),
      body: Column(
        children: [
          // Top Filters
          BusFilterHeader(
            screenWidth: MediaQuery.of(context).size.width,
            screenHeight: MediaQuery.of(context).size.height,
            onSortSelected: (type) {
              setState(() {
                selectedSortType = type;
                sortOrder = sortOrder == SortOrder.ascending ? SortOrder.descending : SortOrder.ascending;
              });
            },
            selectedSortType: selectedSortType,
            sortOrder: sortOrder,
          ),

          // Recommended Toggle
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text("31 Buses Found", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'poppins')),
                Row(
                  children: [
                    Text("Recommended", style: TextStyle(fontSize: 12, fontFamily: 'poppins')),
                    Switch(value: false, onChanged: null),
                  ],
                ),
              ],
            ),
          ),
          // Horizontal Quick Filters
          SizedBox(
            height: 40,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              scrollDirection: Axis.horizontal,
              itemBuilder: (_, index) => Chip(
                label: Text(filters[index], style: TextStyle(fontFamily: 'poppins'),),
                backgroundColor: Colors.grey.shade200,
              ),
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemCount: filters.length,
            ),
          ),
          const Divider(),
          // Scrollable Bus Cards
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(12),
              
              children:  [
                GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>BusAddOnPage()));
                  },
                  child: BusCard(
                    name: "Yolo Bus",
                    departure: "01:28",
                    arrival: "04:49",
                    duration: "03h 21m",
                    rating: "4.8",
                    price: "₹600",
                    features: ["Boarding Point", "Dropping Points", "Cancellation Policy",],
                  ),
                ),
                SizedBox(height: 12),
                
                GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>BusAddOnPage()));
                  },
                  child:BusCard(
                  name: "Raj Kalpana Travels Pvt.Ltd",
                  departure: "04:00",
                  arrival: "08:30",
                  duration: "04h 30m",
                  rating: "4.5",
                  price: "₹700",
                  features: ["Boarding Point", "Dropping Points", "Cancellation Policy",],
                ),)
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 6,
              offset: Offset(0, -1),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildBusBottomTab(context: context, icon: Icons.filter_alt, label: "FILTER"),
            _buildBusBottomTab(context: context, icon: Icons.star_border, label: "RATING"),
            _buildBusBottomTab(context: context, icon: Icons.currency_rupee, label: "PRICE"),
            _buildBusBottomTab(context: context, icon: Icons.event_seat, label: "SEAT TYPE"),
            _buildBusBottomTab(context: context, icon: Icons.sort, label: "SORT", showDot: true),
          ],
        ),
      ),
    );
  }
  Widget _buildBusBottomTab({
    required BuildContext context,
    required IconData icon,
    required String label,
    bool showDot = false,
  }) {
    return GestureDetector(
      onTap: () {
        if (label == "FILTER") {
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (context) => const BusFilterBottomSheet(),
          );
        }
        else if(label == "RATING"){
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (context) => const BusStarFilterSheet(),
          );
        }
        else if(label == "PRICE"){
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (context) => const BusPriceFilterSheet(),
          );
        }
        else if(label == "SEAT TYPE"){
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (context) => BusSeatFilterSheet(),
          );
        }
        else if(label == "SORT"){
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (context) => BusSortFilterSheet(),
          );
        }
        // Add other label checks if needed like "PRICE", "RATING", etc.
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Icon(icon, color: const Color(0xFF4A5568), size: 26),
              if (showDot)
                Positioned(
                  top: -2,
                  right: -2,
                  child: Container(
                    height: 8,
                    width: 8,
                    decoration: const BoxDecoration(
                      color: Color(0xffF73130),
                      shape: BoxShape.circle,
                    ),
                  ),
                )
            ],
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              color: Color(0xFF4A5568),
              fontWeight: FontWeight.w500,
            ),
          )
        ],
      ),
    );
  }
}


