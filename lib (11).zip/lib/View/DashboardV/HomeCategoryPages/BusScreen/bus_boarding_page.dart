import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/bus_review_and_travellers_page.dart';
import 'package:trip_go/View/Widgets/custom_app_bar.dart';
import 'package:trip_go/constants.dart';
class BoardingPointSelectionPage extends StatefulWidget {
  @override
  State<BoardingPointSelectionPage> createState() => _BoardingPointSelectionPageState();
}

class _BoardingPointSelectionPageState extends State<BoardingPointSelectionPage> {
  int? selectedIndex;

  final List<Map<String, String>> boardingPoints = [
    {'time': '2:00 PM', 'location': 'Chinnappanahalli orange travels'},
    {'time': '2:15 PM', 'location': 'Marathahalli,Near HDFC Bank,beside kalanikethan towards silk board.'},
    {'time': '2:25 PM', 'location': 'Bellandur In Front Of Coffee Day,Opposite Centre1 Mall Towards Silk Board'},
    {'time': '2:35 PM', 'location': 'HSR Layout - Towards Silk Board'},
    {'time': '2:45 PM', 'location': 'Madiwala , Market Bus stop'},
    {'time': '2:50 PM', 'location': 'Silk Board - Towards Btm Layout'},
    {'time': '3:00 PM', 'location': 'BTM Layout -Near Udupi Garden Towards Jayanagar'},
    {'time': '3:10 PM', 'location': 'East end circle, Opp Royal Enfield showroom...'},
    {'time': '3:20 PM', 'location': 'Jayanagar 4th Block'},
    {'time': '4:00 PM', 'location': 'Anand Rao Circle,Swiss complex race course road'},
    {'time': '4:30 PM', 'location': 'Yeshwantpur - Gowardhan Theatre'},
    {'time': '4:40 PM', 'location': 'Goragunte Palya - People Tree Hospital'},
    {'time': '4:50 PM', 'location': 'Jalahalli Cross,Near GSR Travels'},
    {'time': '5:00 PM', 'location': '8th mail Rachana travels'},
    {'time': '5:15 PM', 'location': '8th Mail - Parle Toll'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        title: "Select Boarding Point",
        titleStyle: GoogleFonts.poppins(color: Colors.black, fontWeight: FontWeight.w600, fontSize: 20),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            Text('Choose Boarding Point', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            Expanded(
              child: Container(
                 margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(12),
                        ),
                child: ListView.builder(
                  itemCount: boardingPoints.length,
                  itemBuilder: (context, index) {
                    final point = boardingPoints[index];
                    final isSelected = index == selectedIndex;
                
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedIndex = index;
                        });
                
                        // Navigate after slight delay to see the selection
                        Future.delayed(const Duration(milliseconds: 150), () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => DroppingPointSelectionPage()),
                          );
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                        decoration: BoxDecoration(
                          color: isSelected ? constants.themeColor1.withOpacity(0.1) : Colors.white,
                          border: Border.all(
                            color: isSelected ? constants.themeColor1 : Colors.grey.shade300,
                            width: 1.4,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(point['time']!,
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w600,
                                  color: isSelected ? constants.themeColor1 : Colors.black,
                                )),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(point['location']!,
                                  style: GoogleFonts.poppins(
                                    height: 1.4,
                                    color: isSelected ? constants.themeColor1 : Colors.black,
                                  )),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
class DroppingPointSelectionPage extends StatefulWidget {
  @override
  State<DroppingPointSelectionPage> createState() => _DroppingPointSelectionPageState();
}

class _DroppingPointSelectionPageState extends State<DroppingPointSelectionPage> {
  int? selectedIndex;

  final List<Map<String, String>> droppingPoints = [
    {'time': '7:20 AM', 'location': 'Kalamboli - Near MCdonalds Under Public Skywalk'},
    {'time': '7:30 AM', 'location': 'Kharghar - Hiranandani Complex, Three Star Hotel'},
    {'time': '7:35 AM', 'location': 'CBD Belapur- Fly Over Bridge End Towards Nerul'},
    {'time': '7:40 AM', 'location': 'Nerul- Bikaner Corner,I P Signal'},
    {'time': '7:45 AM', 'location': 'Sanpada-Shop No. 21 Sai Kala Building, Near Manmohan Sweets'},
    {'time': '7:50 AM', 'location': 'Vashi- Old Toll Naka Bridge Starting,Opp Green Escape'},
    {'time': '8:10 AM', 'location': 'Chembur - Mahalaxmi Annadata Ahar Kendre, Near Telecom Factory'},
    {'time': '8:25 AM', 'location': 'Sion - Orange Travels Office, Chunabhatti Bridge Ending'},
    {'time': '8:40 AM', 'location': 'Bandra (E) - Kalanagar Best Bus Stop'},
    {'time': '8:45 AM', 'location': 'Santacruz-(E) Panbai High School,Bridge Start'},
    {'time': '8:50 AM', 'location': 'Vile Parle (E) - Before Flyover Opp Megral Marbal Shop'},
    {'time': '9:00 AM', 'location': 'Andheri E - Bridge Starting Hanuman Road Bus Stop'},
    {'time': '9:00 AM', 'location': 'Andheri (E) - Andheri Flyover Ending Hanuman Road Bus Stop'},
    {'time': '9:05 AM', 'location': 'Jogeshwari (E) - Opp Maruti Showroom'},
    {'time': '9:10 AM', 'location': 'Goregaon (E) - After Aarey Flyover, Virvani Bus Stop'},
    {'time': '9:15 AM', 'location': 'Malad-(E) Pushpa Park Bus Stop Towards Borivali'},
    {'time': '9:20 AM', 'location': 'Kandivali (E) - Opp Samta Nagar Police Chowki'},
    {'time': '9:30 AM', 'location': 'Borivali (E) - Orange Travels, National Park Bridge Ending'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        title: "Select Dropping Point",
        titleStyle: GoogleFonts.poppins(color: Colors.black, fontWeight: FontWeight.w600, fontSize: 20),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            Text('Choose Dropping Point', style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            Expanded(
              child: Container(
                 margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(12),
                        ),
                child: ListView.builder(
                  itemCount: droppingPoints.length,
                  itemBuilder: (context, index) {
                    final point = droppingPoints[index];
                    final isSelected = index == selectedIndex;
                
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedIndex = index;
                        });
                
                        // Proceed to next (dummy) page
                        Future.delayed(const Duration(milliseconds: 150), () {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>BusReviewAndTravellerPage()));
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                        decoration: BoxDecoration(
                          color: isSelected ? constants.themeColor1.withOpacity(0.1) : Colors.white,
                          border: Border.all(
                            color: isSelected ? constants.themeColor1 : Colors.grey.shade300,
                            width: 1.4,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(point['time']!,
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w600,
                                  color: isSelected ? constants.themeColor1 : Colors.black,
                                )),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(point['location']!,
                                  style: GoogleFonts.poppins(
                                    height: 1.4,
                                    color: isSelected ? constants.themeColor1 : Colors.black,
                                  )),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
