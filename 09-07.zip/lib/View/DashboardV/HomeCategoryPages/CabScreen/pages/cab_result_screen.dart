import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/CabScreen/pages/cab_review_screen.dart';
import 'package:trip_go/View/Widgets/Drawer/custom_drawer.dart';
import '../../HotelScreen/Filters/sort_by_bottom_sheet.dart';
import '../widgets/cab_app_bar.dart';
import '../widgets/cab_bottom_bar.dart';
import '../widgets/filter_bottom_sheet.dart';

class CabResultScreen extends StatelessWidget {
  const CabResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CabAppBar(
        title: 'Delhi to NOIDA',
        subline: "Thursday, 10 July, 2025 08:30 AM",
        onBack: () => Navigator.pop(context),
        onSearchTap: () {},
        onEditTap: () async {},
      ),
      body: Column(
        children: [
          _buildTopInfo(),
          Expanded(
            child: ListView(
              children: [
                _buildCabTile(
                  image: 'https://transfer.easemytrip.com/assets/img/dezire.png', // Replace with your image
                  name: 'Dzire, Etios or equivalent',
                  price: 879,
                  discount: 74,
                  onTap: () {
                    // Navigate or perform any action
                    print("Cab tile tapped!");
                    Navigator.push(context, MaterialPageRoute(builder: (context) => CabReviewScreen()));
                  },
                ),
                _buildCabTile(
                  image: 'https://transfer.easemytrip.com/assets/img/wagonr.png', // Replace with your image
                  name: 'Swift, Celerio or equivalent',
                  price: 891,
                  discount: 94,
                  onTap: () {
                    // Navigate or perform any action
                    print("Cab tile tapped!");
                  },
                ),
                _buildCabTile(
                  image: 'https://transfer.easemytrip.com/assets/img/xylo.png', // Replace with your image
                  name: 'Wagon R or Equivalent',
                  price: 905,
                  discount: 60,
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: CabFilterBottomSheet(
        onFilterTap: () async {
          final result = await showModalBottomSheet<Set<String>>(
            context: context,
            isScrollControlled: true,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            builder: (_) => const FilterBottomSheet(),
          );

        },
        onSortTap:() async {
          final  result = await showModalBottomSheet<String?>(
            context: context,
            isScrollControlled: true,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            builder: (_) => const SortByBottomSheet(),
          );

        },
        showSortNotification: true, // or false based on state
      ),
    );
  }

  Widget _buildTopInfo() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Colors.white, Color(0xFFFFEBEE), Color(0xFFFFF5F6)],
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: const [
          _InfoIcon(text: "Save up to 30%", icon: CupertinoIcons.hand_thumbsup,),
          _InfoIcon(text: "Professional Drivers", icon: CupertinoIcons.person),
          _InfoIcon(text: "24*7 Support", icon: Icons.chat_bubble_outline),
        ],
      ),
    );
  }

  Widget _buildCabTile({
    required String image,
    required String name,
    required int price,
    required int discount,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Card(
        color: Colors.white,
        margin: const EdgeInsets.all(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ✅ Image with increased size and border
                  Container(
                    width: 120,
                    height: 110,
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade400),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(5),
                      child: Image.network(image, fit: BoxFit.contain),
                    ),
                  ),

                  const SizedBox(width: 10),

                  // ✅ This Expanded ensures the right content takes remaining width and wraps if needed
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // ✅ Wrapping name if it's long
                        Text(
                          name,
                          softWrap: true,
                          overflow: TextOverflow.visible,
                          maxLines: 2,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'poppins',
                          ),
                        ),

                        const SizedBox(height: 10),

                        // ✅ Info rows wrapped in container to control width
                        Column(
                          children: [
                            Row(
                              children: [
                                Expanded(child: _buildInfoBox(Icons.directions_car, "1 Unit")),
                                const SizedBox(width: 5),
                                Expanded(child: _buildInfoBox(Icons.airline_seat_recline_extra, "4 Seat")),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(child: _buildInfoBox(Icons.luggage, "1 Luggage")),
                                const SizedBox(width: 5),
                                Expanded(child: _buildInfoBox(Icons.location_on, "26 Km")),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text("₹ $price", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'poppins')),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.green),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min, // prevents full width
                            children: const [
                              Icon(Icons.check_circle, color: Colors.green, size: 16),
                              SizedBox(width: 5),
                              Flexible(
                                child: Text(
                                  "TGOCAB Applied",
                                  style: TextStyle(color: Colors.green, fontSize: 12, fontFamily: 'poppins'),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          "Book Now and Get Rs $discount OFF",
                          style: TextStyle(
                              color: constants.themeColor1,
                              fontFamily: 'poppins',
                              fontSize: 11,
                              fontWeight: FontWeight.w500
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Divider(),
              const SizedBox(height: 5),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      _buildTag("Safety standards", Icons.shield),
                      const SizedBox(width: 10),
                      _buildTag("Partial Payment", Icons.payment),
                    ],
                  ),
                  Icon(Icons.info_outline, color: constants.themeColor1,),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTag(String text, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        border: Border.all(color: constants.themeColor1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, size: 14, color: constants.themeColor1),
          const SizedBox(width: 5),
          Text(text, style: TextStyle(fontSize: 9, color: constants.themeColor1, fontFamily: 'poppins')),
        ],
      ),
    );
  }

  Widget _buildBottomButton(IconData icon, String label) {
    return Expanded(
      child: InkWell(
        onTap: () {},
        child: Container(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, ),
              Text(label),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _buildInfoBox(IconData icon, String text) {
  return Container(
    width: 110, // fix equal width to align rows uniformly
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Icon(icon, size: 16, color: Colors.black87),
        const SizedBox(width: 5),
        Flexible(
          child: Text(
            text,
            style: const TextStyle(fontSize: 12, fontFamily: 'poppins'),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    ),
  );
}


class _InfoIcon extends StatelessWidget {
  final String text;
  final IconData icon;

  const _InfoIcon({required this.text, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: constants.themeColor1),
        const SizedBox(height: 4),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontFamily: 'poppins',)),
      ],
    );
  }
}
//