import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/CabScreen/widgets/cab_traveller_details_card.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/CabScreen/widgets/trip_details_card.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/FlightScreen/FlightWidgets/gst_bottom_sheet.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/hotel_promo_section.dart';
import 'package:trip_go/constants.dart';

import '../../FlightScreen/common_widget/bottom_bar.dart';
import '../widgets/payment_option_card.dart';

class CabReviewScreen extends StatefulWidget {
  const CabReviewScreen({super.key});

  @override
  State<CabReviewScreen> createState() =>
      _CabReviewScreenState();
}

class _CabReviewScreenState extends State<CabReviewScreen> {
  bool? isInsuranceSelected; // null by default, or use `true` for preselection
  bool isChecked = false;
  bool isCheckedGst = false;
  String? errorMessage;
  String? companyName;
  String? regNo;

  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 130,
      decoration: BoxDecoration(
        color: constants.themeColor1,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 36),
      alignment: Alignment.topLeft,
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: const Icon(Icons.arrow_back, color: Colors.white),
          ),
          const SizedBox(width: 16),
          Text(
            "Cab Review & Traveler",
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGstSection() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
        border: Border.all(color: Colors.grey.withOpacity(.4)),
      ),
      child: Row(
        children: [
          Checkbox(
            value: isCheckedGst,
            onChanged: (val) async {
              setState(() {
                isCheckedGst = val!;
              });
              if (val == true) {
                final result = await showModalBottomSheet<Map<String, String>>(
                  context: context,
                  isScrollControlled: true,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(5),
                    ),
                  ),
                  builder:
                      (context) => const Padding(
                    padding: EdgeInsets.only(
                      bottom: 20,
                      top: 20,
                      left: 16,
                      right: 16,
                    ),
                    child: GstBottomSheet(),
                  ),
                );
                if (result != null) {
                  companyName = result['companyName'];
                  regNo = result['registrationNo'];
                }
              }
            },
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Use GST for this booking (OPTIONAL)",
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  "To claim credit of GST charged by hotels/TripGo, please enter your company's GST number.",
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTermsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
      child: Row(
        children: [
          Checkbox(
            value: isChecked,
            onChanged: (val) {
              setState(() {
                isChecked = val!;
              });
            },
          ),
          RichText(
            text: TextSpan(
              style: GoogleFonts.poppins(color: Colors.black),
              children: [
                const TextSpan(text: "I Accept "),
                TextSpan(
                  text: "T&C ",
                  style: const TextStyle(color: Colors.blue),
                ),
                const TextSpan(text: "and "),
                TextSpan(
                  text: "Privacy Policy",
                  style: const TextStyle(color: Colors.blue),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  bool showDetails = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: buildBottomBar(
        context,
            () {
        },
        price: 899,
      ),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            _buildHeader(context),
            Padding(
              padding: const EdgeInsets.fromLTRB(16,90,16,20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // BUS DETAIL CARD
                  _buildBusDetailCard(),
                  const SizedBox(height: 16),
                  // TRAVELLER DETAILS
                  CabTravellerDetailsCard(),
                  const SizedBox(height: 12),
                  TripDetailsCard(),
                  const SizedBox(height: 12),
                  PaymentOptionCard(),
                  const SizedBox(height: 12),
                  HotelPromoSection(),
                  const SizedBox(height: 12),
                  _buildGstSection(),
                  const SizedBox(height: 12),
                  _buildTermsSection()
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCircle() {
    return Container(
      width: 10,
      height: 10,
      decoration: const BoxDecoration(
        color: Colors.black,
        shape: BoxShape.circle,
      ),
    );
  }

  Widget _buildDashedLine({double height = 140}) {
    return Container(
      height: height,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(10, (_) {
          return Container(width: 2, height: 4, color: Colors.grey.shade400);
        }),
      ),
    );
  }

  Widget _buildBusDetailCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title and Date
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Delhi To Noida',
                    style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
                  ),
                  Text(
                    'Pickup : Thursday, 10 July, 2025',
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),
          Divider(),
          Row(
            children: [
              Container(
                width: 120,
                height: 80,
                padding: const EdgeInsets.all(4),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5),
                  child: Image.network("https://transfer.easemytrip.com/assets/img/dezire.png", fit: BoxFit.contain),
                ),
              ),
              SizedBox(width: 4,),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Dzire, Etios or equivalent",
                    softWrap: true,
                    overflow: TextOverflow.visible,
                    maxLines: 2,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'poppins',
                    ),
                  ),
                  Text(
                    "1 Unit | 4 Seat 1 Luggage Bag | 26\n Km",
                    style: const TextStyle(
                      fontSize: 10,
                      fontFamily: 'poppins',
                    ),
                  ),
                ],
              ),
            ],
          ),
          Divider(),
          _buildCabDetailsList()
        ],
      ),
    );
  }

  Widget _buildCabDetailsList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInlineInfoRow(
          icon: Icons.directions_car,
          title: "Kilometer Charges",
          value: "26 km included after that ₹10/km",
        ),
        _buildInlineInfoRow(
          icon: Icons.local_gas_station,
          title: "Fuel Type",
          value: "CNG",
        ),
        _buildInlineInfoRow(
          icon: Icons.check_circle_outline,
          title: "Free Cancellation",
          value: "before 6 hours from the journey time",
        ),
      ],
    );
  }

  Widget _buildInlineInfoRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(icon, size: 20, color: Colors.grey[800]),
          const SizedBox(width: 10),
          Expanded(
            flex: 2,
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 8,
                fontWeight: FontWeight.w500,
                fontFamily: 'poppins',
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontSize: 8,
                color: Colors.black87,
                fontFamily: 'poppins',
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: constants.themeColor1, size: 20),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.poppins(fontSize: 13, color: Colors.black54),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class TravellerDetailCard extends StatefulWidget {
  final int index;
  final String seat;

  const TravellerDetailCard({
    super.key,
    required this.index,
    required this.seat,
  });

  @override
  State<TravellerDetailCard> createState() => _TravellerDetailCardState();
}

class _TravellerDetailCardState extends State<TravellerDetailCard> {
  String selectedGender = "";

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "ADULT ${widget.index}",
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  widget.seat,
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: constants.themeColor2,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Gender Selection
          Row(
            children: [
              Expanded(child: _genderButton("Male")),
              const SizedBox(width: 12),
              Expanded(child: _genderButton("Female")),
            ],
          ),

          const SizedBox(height: 10),

          // Name Fields
          _labelledTextField(
            "First Name (& Middle name if any)",
            "Enter First Name",
          ),
          const SizedBox(height: 10),

          Row(
            children: [
              Expanded(
                child: _labelledTextField("Last Name", "Enter Last Name"),
              ),
              const SizedBox(width: 12),
              Expanded(child: _labelledTextField("Age", "Enter Age")),
            ],
          ),
        ],
      ),
    );
  }

  Widget _genderButton(String text) {
    final bool isSelected = selectedGender == text;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedGender = text;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color:
          isSelected
              ? constants.themeColor1.withOpacity(0.1)
              : Colors.transparent,
          border: Border.all(
            color: isSelected ? constants.themeColor1 : Colors.grey.shade300,
          ),
          borderRadius: BorderRadius.circular(10),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: GoogleFonts.poppins(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: isSelected ? constants.themeColor1 : Colors.black54,
          ),
        ),
      ),
    );
  }

  Widget _labelledTextField(String label, String hint) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: GoogleFonts.poppins(fontSize: 13)),
        const SizedBox(height: 6),
        TextField(
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: GoogleFonts.poppins(fontSize: 13),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
          ),
        ),
      ],
    );
  }
}
