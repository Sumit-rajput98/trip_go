enum BusSortType { departure, duration, price }
enum SortOrder { ascending, descending }