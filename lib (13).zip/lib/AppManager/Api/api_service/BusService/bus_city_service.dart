import 'package:trip_go/AppManager/Api/api_service/api_call.dart';
import 'package:trip_go/AppManager/Api/api_service/api_constant.dart';

import '../../../../Model/BusM/bus_city_model.dart';

class BusCityService {
  Future<List<BusCity>> fetchBusCities() async {
    final response = await ApiCall().call(
      url: 'api/Bus/City',
      apiCallType: ApiCallType.get(),
    );

    if (response['success'] == true) {
      final List cities = response['data'];
      return cities.map((e) => BusCity.fromJson(e)).toList();
    } else {
      throw Exception('Failed to load bus cities');
    }
  }
}
