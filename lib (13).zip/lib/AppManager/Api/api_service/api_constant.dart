class ApiConstant{
  static String baseUrl = "https://admin.tripgoonline.com/";
  // static String baseUrl = "https://admin.travelsdata.com/";
}