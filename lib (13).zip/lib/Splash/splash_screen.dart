import 'dart:async';
import 'package:flutter/material.dart';
import 'package:trip_go/View/DashboardV/bottom_navigation_bar.dart';
import 'package:trip_go/constants.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:google_fonts/google_fonts.dart';

class TripGoSplash extends StatefulWidget {
  const TripGoSplash({super.key});

  @override
  State<TripGoSplash> createState() => _TripGoSplashState();
}

class _TripGoSplashState extends State<TripGoSplash> with TickerProviderStateMixin {
  final List<String> originalImages = [
    'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1465156799763-2c087c332922?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=400&q=80',
    'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=400&q=80',
  ];

  late List<String> gridImages;
  late List<AnimationController> _controllers;
  late List<Animation<Offset>> _offsetAnimations;
  bool navigating = false;

  @override
  void initState() {
    super.initState();

    // Repeat images if needed
    gridImages = List.generate(18, (i) => originalImages[i % originalImages.length]);

    _controllers = List.generate(
      gridImages.length,
      (i) => AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 900),
      ),
    );

    _offsetAnimations = List.generate(
      gridImages.length,
      (i) => Tween<Offset>(begin: const Offset(0, 1.5), end: Offset.zero).animate(
        CurvedAnimation(parent: _controllers[i], curve: Curves.easeOutBack),
      ),
    );

    _startAnimations();
  }

  void _startAnimations() async {
    for (int i = 0; i < _controllers.length; i++) {
      await Future.delayed(Duration(milliseconds: 80));
      _controllers[i].forward();
    }

    await Future.delayed(const Duration(milliseconds: 1800));
    if (mounted && !navigating) {
      navigating = true;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const BottomNavigationbar()),
      );
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  Widget buildMasonryGrid(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Positioned.fill(
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          bottom: size.height * 0.3 , // just above the curve
          top: size.height * 0.08,
        ),
        child: MasonryGridView.count(
          crossAxisCount: 3,
          mainAxisSpacing: 14,
          crossAxisSpacing: 12,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: gridImages.length,
          itemBuilder: (context, idx) {
            final double imgH = (idx % 3 == 0)
                ? size.width / 2.1
                : (idx % 3 == 1)
                    ? size.width / 2.6
                    : size.width / 2.3;
            final double imgW = size.width / 3.6;

            return SlideTransition(
              position: _offsetAnimations[idx],
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.network(
                  gridImages[idx],
                  width: imgW,
                  height: imgH,
                  fit: BoxFit.cover,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          buildMasonryGrid(context),

          // Bottom curved container with logo
          Align(
            alignment: Alignment.bottomCenter,
            child: ClipPath(
              clipper: TopRoundedCurveClipper(),
              child: Container(
                height: size.height * 0.32,
                width: double.infinity,
                color: Colors.grey.shade400,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset('assets/images/trip_go.png', height: 60),
                    const SizedBox(height: 12),
                     Text(
                      'Powering magical trips for modern explorers',
                      style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w500)
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// A top-rounded curve (concave down)
class TopRoundedCurveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(0, 40); // Start a bit down for curve
    path.quadraticBezierTo(size.width / 2, 0, size.width, 40);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
