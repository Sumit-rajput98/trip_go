import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../../../Model/BusM/bus_seat_model.dart';
import '../../../../../Model/BusM/selected_seat_model.dart';
import '../../../../../constants.dart';
import '../BusScreen/bus_seat_provider.dart';

class ChartTab extends StatelessWidget {
  final SeatLayoutModel seatLayout;
  final String htmlLayout;

  const ChartTab({
    super.key,
    required this.seatLayout,
    required this.htmlLayout,
  });

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              height: 46,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: constants.themeColor1),
              ),
              child: const TabBar(
                dividerHeight: 0,
                labelColor: Colors.black,
                unselectedLabelColor: Colors.black54,
                labelStyle: TextStyle(fontWeight: FontWeight.w600),
                unselectedLabelStyle: TextStyle(fontWeight: FontWeight.w500),
                indicatorSize: TabBarIndicatorSize.tab,
                tabs: [
                  Tab(text: 'LOWER SEAT'),
                  Tab(text: 'UPPER SEAT'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SeatIndicator(color: Colors.pinkAccent, label: "Ladies"),
                SeatIndicator(color: Colors.green, label: "Selected"),
                SeatIndicator(color: Colors.white, border: true, label: "Available"),
                SeatIndicator(color: Colors.grey, label: "Booked"),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: TabBarView(
              children: [
                HtmlLayoutView(html: htmlLayout, isUpper: false, seatLayout: seatLayout),
                HtmlLayoutView(html: htmlLayout, isUpper: true, seatLayout: seatLayout),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SeatIndicator extends StatelessWidget {
  final Color color;
  final String label;
  final bool border;
  const SeatIndicator({super.key, required this.color, required this.label, this.border = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            border: border ? Border.all(color: Colors.black26) : null,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 4),
        Text(label, style: GoogleFonts.poppins(fontSize: 12)),
      ],
    );
  }
}

class HtmlLayoutView extends StatelessWidget {
  final String html;
  final bool isUpper;
  final SeatLayoutModel seatLayout;

  const HtmlLayoutView({
    super.key,
    required this.html,
    required this.isUpper,
    required this.seatLayout,
  });

  @override
  Widget build(BuildContext context) {
    final seatProvider = Provider.of<BusSeatProvider>(context);

    // Get filtered seats
    final allSeats = seatLayout.seatDetails.expand((row) => row).toList();
    final seatsToShow = allSeats.where((seat) => seat.isUpper == isUpper).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Html(
            data: html,
            style: {
              "*": Style(margin: Margins.zero),
              ".seatcontainer": Style(width: Width.auto(), height: Height.auto()),
            },
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 12,
            children: seatsToShow.map((seat) {
              final isBooked = !seat.seatStatus;
              final isSelected = seatProvider.isSelected(seat.seatName);

              Color bgColor = Colors.white;
              Color textColor = Colors.black;

              if (seat.isLadiesSeat) bgColor = Colors.pinkAccent;
              if (isBooked) {
                bgColor = Colors.grey;
                textColor = Colors.white;
              } else if (isSelected) {
                bgColor = Colors.green;
                textColor = Colors.white;
              }

              return GestureDetector(
                onTap: isBooked
                    ? null
                    : ()  {
                  final selectedSeat = SelectedSeatModel(
                    seatName: seat.seatName,
                    seatIndex: seat.seatIndex.toString(),
                    rowNo: seat.rowNo,
                    columnNo: seat.columnNo,
                    isLadiesSeat: seat.isLadiesSeat,
                    isMalesSeat: seat.isMalesSeat,
                    isUpper: seat.isUpper,
                    seatType: seat.seatType,
                    height: seat.height,
                    width: seat.width,
                    seatStatus: seat.seatStatus,
                    price: seat.price,
                  );
                  seatProvider.toggleSeat(selectedSeat);
                },
                child: Container(
                  width: 50,
                  height: 60,
                  decoration: BoxDecoration(
                    color: bgColor,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Colors.grey),
                  ),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        seat.seatName,
                        style: GoogleFonts.poppins(color: textColor, fontSize: 13),
                      ),
                      if (!isBooked)
                        if (!isBooked)
                          Text(
                            '₹${seat.price.basePrice}', // <-- always show from model
                            style: GoogleFonts.poppins(fontSize: 11, color: textColor),
                          ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

