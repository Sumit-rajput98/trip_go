import 'package:trip_go/Model/FlightM/upsell_model.dart';

class SelectedUpsellData {
  final Result result;
  final int price;

  SelectedUpsellData({required this.result, required this.price});
}
