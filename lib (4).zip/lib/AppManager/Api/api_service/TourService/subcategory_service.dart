import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../../../Model/TourM/subcategory_model.dart';

class SubCategoryService {
  Future<SubCategoryModel?> fetchSubCategory(String slug2) async {
    final url = 'https://admin.travelsdata.com/api/HolidayPackages/destinations/switzerland/$slug2';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        return SubCategoryModel.fromJson(jsonData);
      } else {
        print('Failed to load subcategory data');
        return null;
      }
    } catch (e) {
      print('Error fetching subcategory: $e');
      return null;
    }
  }
}
