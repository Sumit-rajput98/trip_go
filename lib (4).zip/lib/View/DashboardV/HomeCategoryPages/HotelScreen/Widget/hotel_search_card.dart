import 'package:flutter/material.dart';
import '../../../../Widgets/gradient_button.dart';
import '../../TourScreen/TourWidget/date_picker_field.dart';
import 'date_picker_field_for_hotel.dart';
import 'package:intl/intl.dart';

class HotelSearchCard extends StatefulWidget {
  HotelSearchCard({super.key});

  @override
  State<HotelSearchCard> createState() => _HotelSearchCardState();
}

class _HotelSearchCardState extends State<HotelSearchCard> {
  final TextEditingController checkInController = TextEditingController();
  final TextEditingController checkOutController = TextEditingController();

  String? checkInDay;
  String? checkOutDay;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 4,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            const Divider(),

            // Search Input
            TextFormField(
              initialValue: "Enter City Name, Location, Or Specific Hotel",
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[700],
                fontFamily: 'poppins',
              ),
              decoration: const InputDecoration(
                border: InputBorder.none,
                isDense: true,
              ),
            ),
            const SizedBox(height: 8),

            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  initialValue: "BARAKHAMBA, NEW DELHI",
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    fontFamily: 'poppins',
                  ),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 2),
                TextFormField(
                  initialValue: "NATIONAL CAPITAL TERRITORY OF DELHI",
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black54,
                    fontFamily: 'poppins',
                  ),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    isDense: true,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Check-in & Check-out
            Row(
              children: [
                // ✅ Check-In
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Check-In", style: TextStyle(fontSize: 14, fontFamily: 'poppins')),
                      const SizedBox(height: 4),
                      DatePickerFieldForHotel(
                        controller: checkInController,
                        onDateSelected: (date) {
                          setState(() {
                            checkInDay = DateFormat('EEEE').format(date); // e.g. Monday
                          });
                        },
                      ),
                      Text(
                        checkInDay ?? "Select a date",
                        style: const TextStyle(fontSize: 12, fontFamily: 'poppins'),
                      ),
                    ],
                  ),
                ),

                // Vertical Divider
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    height: 50,
                    width: 1,
                    color: Colors.grey,
                  ),
                ),

                // ✅ Check-Out
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Check-Out", style: TextStyle(fontSize: 14, fontFamily: 'poppins')),
                      const SizedBox(height: 4),
                      DatePickerFieldForHotel(
                        controller: checkOutController,
                        onDateSelected: (date) {
                          setState(() {
                            checkOutDay = DateFormat('EEEE').format(date); // e.g. Friday
                          });
                        },
                      ),
                      Text(
                        checkOutDay ?? "Select a date",
                        style: const TextStyle(fontSize: 12, fontFamily: 'poppins'),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),

            // Rooms & Guests
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Rooms & Guests", style: TextStyle(fontFamily: 'poppins')),
                const SizedBox(height: 4),
                TextFormField(
                  initialValue: "1 Guest, 1 Room",
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    fontFamily: 'poppins',
                  ),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    isDense: true,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            GradientButton(
              label: 'SEARCH HOTEL',
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }
}
