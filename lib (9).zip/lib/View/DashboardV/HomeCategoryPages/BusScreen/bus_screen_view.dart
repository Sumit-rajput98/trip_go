import 'package:flutter/material.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/bus_search_card.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/popular_bus_destinatoins.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/BusScreen/why_book_with_us_section.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/Widget/view_more_button.dart';

class BusScreenView extends StatefulWidget {
  const BusScreenView({super.key});

  @override
  State<BusScreenView> createState() => _BusScreenViewState();
}

class _BusScreenViewState extends State<BusScreenView> {
  @override
  Widget build(BuildContext context) {
   return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: const [
             BusSearchCard2(),
             const SizedBox(height: 20,),
             PopularBusDestinatoins(),
             SizedBox(height: 10,),
            ViewMoreButton(),
            SizedBox(height: 10,),
            WhyBookWithUsSection()
          ],
        ),
      ),
    );
 
  }
}