import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/CabScreen/pages/cab_review_screen.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/CabScreen/widgets/cab_search_card.dart';

class CabResultScreen extends StatefulWidget {
  const CabResultScreen({super.key});

  @override
  State<CabResultScreen> createState() => _CabResultScreenState();
}

class _CabResultScreenState extends State<CabResultScreen>
    with TickerProviderStateMixin {
  
  // Theme colors
  static const Color themeColor1 = Color(0xff1B499F);
  static const Color themeColor2 = Color(0xffF73130);
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  
  int selectedFilter = 0;
  bool showPriceBreakdown = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.elasticOut,
    ));
    
    _animationController.forward();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildLightAppBar(context, size),
          _buildJourneyInfoCard(context),
          _buildSmartFilters(context),
          _buildCabList(context),
         
        ],
      ),
      floatingActionButton: _buildFloatingNavigation(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
// **Light Theme App Bar**
Widget _buildLightAppBar(BuildContext context, Size size) {
  return SliverAppBar(
    floating: false,
    pinned: true,
    scrolledUnderElevation: 0,
    backgroundColor: Colors.white,
    systemOverlayStyle: SystemUiOverlayStyle.dark,
    elevation: 0,
    title: AnimatedBuilder(
      animation: _fadeAnimation,
      builder: (context, child) => FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.green.shade600),
                  ),
                  child: Text(
                    'LIVE',
                    style: GoogleFonts.poppins(
                      color: Colors.green.shade700,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Delhi → Noida',
                  style: GoogleFonts.poppins(
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ],
            ),
            Text(
              'Today • 8:30 AM • 3 cabs available',
              style: GoogleFonts.poppins(
                color: Colors.grey.shade600,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    ),
    leading: IconButton(
      icon: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.grey.shade100,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Icon(Icons.arrow_back_ios_new, color: themeColor1),
      ),
      onPressed: () => Navigator.pop(context),
    ),
    actions: [
      // Search Button
      IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: Icon(Icons.search, color: themeColor1),
        ),
        onPressed: () {
          _showSearchBottomSheet(context);
        },
      ),
      // Edit Button
      IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: Icon(Icons.edit_outlined, color: themeColor1),
        ),
        onPressed: () {
          _showEditBottomSheet(context);
        },
      ),
      const SizedBox(width: 8),
    ],
  );
}
void _showDateTimeEditDialog(BuildContext context) {
  showModernDateTimePicker(
    context: context,
    initialDate: DateTime.now(),
    onDateSelected: (dt) {
      setState(() {
        // Update your date/time state here
      });
    },
  );
}

void _showPreferencesDialog(BuildContext context) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (context) => Container(
      padding: const EdgeInsets.all(20),
      height: 300,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Add Preferences',
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          
          // Overseas checkbox
          CheckboxListTile(
            title: Text('Overseas', style: GoogleFonts.poppins()),
            value: false, // Replace with your state
            activeColor: themeColor1,
            onChanged: (value) {
              // Handle overseas toggle
            },
          ),
          
          // Travellers option
          ListTile(
            leading: Icon(Icons.person_outline, color: themeColor1),
            title: Text('Travellers', style: GoogleFonts.poppins()),
            subtitle: Text('Add adult & child count', 
                         style: GoogleFonts.poppins(fontSize: 12)),
            trailing: Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              // Show traveller selection
            },
          ),
          
          // Luggage option
          ListTile(
            leading: Icon(Icons.luggage_outlined, color: themeColor1),
            title: Text('Luggage', style: GoogleFonts.poppins()),
            subtitle: Text('Add carry & checked-in luggage', 
                         style: GoogleFonts.poppins(fontSize: 12)),
            trailing: Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              // Show luggage selection
            },
          ),
        ],
      ),
    ),
  );
}

// Add the showModernDateTimePicker method from your CabSearchCard
void showModernDateTimePicker({
  required BuildContext context,
  required DateTime? initialDate,
  required Function(DateTime) onDateSelected,
}) {
  DateTime tempPicked = _roundToNearestInterval(
    initialDate ?? DateTime.now(),
    15,
  );

  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (context) {
      return Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Text(
                        "Cancel",
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const Spacer(),
                    const Text(
                      "Select Date and Time",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        onDateSelected(tempPicked);
                      },
                      child: Text(
                        "Done",
                        style: TextStyle(
                          fontSize: 14,
                          color: themeColor1,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, thickness: 0.8),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.3,
                child: CupertinoDatePicker(
                  mode: CupertinoDatePickerMode.dateAndTime,
                  initialDateTime: tempPicked,
                  minuteInterval: 15,
                  use24hFormat: true,
                  minimumYear: 2000,
                  maximumYear: DateTime.now().year + 10,
                  onDateTimeChanged: (DateTime newDateTime) {
                    tempPicked = newDateTime;
                  },
                ),
              ),
              SizedBox(height: MediaQuery.of(context).padding.bottom),
            ],
          ),
        ),
      );
    },
  );
}

DateTime _roundToNearestInterval(DateTime dt, int interval) {
  int minute = dt.minute;
  int remainder = minute % interval;
  int adjustedMinutes = remainder == 0 ? minute : minute - remainder;
  return DateTime(dt.year, dt.month, dt.day, dt.hour, adjustedMinutes);
}

void _showEditBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (context) => Container(
      height: MediaQuery.of(context).size.height * 0.7,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            width: 40,
            height: 5,
            margin: const EdgeInsets.only(top: 12, bottom: 20),
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          
          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Icon(Icons.edit_outlined, color: themeColor1, size: 24),
                const SizedBox(width: 12),
                Text(
                  'Edit Journey Details',
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: Icon(Icons.close, color: Colors.grey.shade600),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          
          Divider(color: Colors.grey.shade200),
          
          // Edit options
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _buildEditOption(
                  context,
                  'Change Route',
                  'Delhi → Noida',
                  Icons.route,
                  () {
                    Navigator.pop(context);
                    _showSearchBottomSheet(context);
                  },
                ),
                _buildEditOption(
                  context,
                  'Change Date & Time',
                  'Today • 8:30 AM',
                  Icons.access_time,
                  () {
                    Navigator.pop(context);
                    _showDateTimeEditDialog(context);
                  },
                ),
                _buildEditOption(
                  context,
                  'Change Trip Type',
                  'Airport Transfer',
                  Icons.flight_takeoff,
                  () {
                    Navigator.pop(context);
                    _showSearchBottomSheet(context);
                  },
                ),
                _buildEditOption(
                  context,
                  'Add Preferences',
                  'Overseas, Travellers, Luggage',
                  Icons.tune,
                  () {
                    Navigator.pop(context);
                    _showPreferencesDialog(context);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _buildEditOption(
  BuildContext context,
  String title,
  String subtitle,
  IconData icon,
  VoidCallback onTap,
) {
  return Container(
    margin: const EdgeInsets.only(bottom: 16),
    child: Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: themeColor1.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: themeColor1, size: 20),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.grey.shade400,
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

void _showSearchBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.9,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                width: 40,
                height: 5,
                margin: const EdgeInsets.only(top: 12, bottom: 20),
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              
              // Header
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Icon(Icons.search, color: themeColor1, size: 24),
                    const SizedBox(width: 12),
                    Text(
                      'Modify Search',
                      style: GoogleFonts.poppins(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.grey.shade600),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 10),
              
              // Search form - embedded CabSearchCard
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8.0),
                    child: CabSearchCard(),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    ),
  );
}

  // **Journey Info Card - Light Theme**
  Widget _buildJourneyInfoCard(BuildContext context) {
    return SliverToBoxAdapter(
      child: AnimatedBuilder(
        animation: _slideAnimation,
        builder: (context, child) => SlideTransition(
          position: _slideAnimation,
          child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.grey.shade200),
              boxShadow: [
                BoxShadow(
                  color: themeColor1.withOpacity(0.1),
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    children: [
                      _buildJourneyPoint('Delhi', 'Connaught Place', true),
                      _buildJourneyLine(),
                      _buildJourneyPoint('Noida', 'Sector 62', false),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Column(
                  children: [
                    _buildInfoBadge('26 km', Icons.route, themeColor1),
                    const SizedBox(height: 8),
                    _buildInfoBadge('45 min', Icons.access_time, Colors.orange.shade600),
                    const SizedBox(height: 8),
                    _buildInfoBadge('₹879+', Icons.currency_rupee, Colors.green.shade600),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildJourneyPoint(String city, String area, bool isStart) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: isStart ? Colors.green.shade600 : themeColor2,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: (isStart ? Colors.green.shade600 : themeColor2).withOpacity(0.3),
                blurRadius: 6,
                spreadRadius: 1,
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              city,
              style: GoogleFonts.poppins(
                color: Colors.black87,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            Text(
              area,
              style: GoogleFonts.poppins(
                color: Colors.grey.shade600,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildJourneyLine() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 2,
            height: 30,
            margin: const EdgeInsets.only(left: 5),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.green.shade600, themeColor2],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBadge(String text, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 4),
          Text(
            text,
            style: GoogleFonts.poppins(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  // **Smart Filters - Light Theme**
  Widget _buildSmartFilters(BuildContext context) {
    final filters = [
      {'name': 'Best Match', 'icon': Icons.auto_awesome, 'color': themeColor1},
      {'name': 'Fastest', 'icon': Icons.speed, 'color': themeColor2},
      {'name': 'Cheapest', 'icon': Icons.savings, 'color': Colors.green.shade600},
      {'name': 'Premium', 'icon': Icons.star, 'color': Colors.amber.shade600},
    ];

    return SliverToBoxAdapter(
      child: Container(
        height: 60,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: filters.length,
          itemBuilder: (context, index) {
            final filter = filters[index];
            final isSelected = selectedFilter == index;
            
            return GestureDetector(
              onTap: () {
                setState(() {
                  selectedFilter = index;
                });
                HapticFeedback.lightImpact();
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.only(right: 12),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? LinearGradient(colors: [
                          (filter['color'] as Color),
                          (filter['color'] as Color).withOpacity(0.8),
                        ])
                      : null,
                  color: isSelected ? null : Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? (filter['color'] as Color)
                        : Colors.grey.shade300,
                    width: isSelected ? 2 : 1,
                  ),
                  boxShadow: isSelected ? [
                    BoxShadow(
                      color: (filter['color'] as Color).withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ] : null,
                ),
                child: Row(
                  children: [
                    Icon(
                      filter['icon'] as IconData,
                      color: isSelected ? Colors.white : (filter['color'] as Color),
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      filter['name'] as String,
                      style: GoogleFonts.poppins(
                        color: isSelected ? Colors.white : (filter['color'] as Color),
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // **Cab List - Light Theme**
  Widget _buildCabList(BuildContext context) {
    final cabs = [
      {
        'name': 'Dzire, Etios or equivalent',
        'subtitle': 'Sedan • AC • 4 Seats',
        'image': 'https://transfer.easemytrip.com/assets/img/dezire.png',
        'price': 879,
        'originalPrice': 953,
        'rating': 4.9,
        'eta': '3 min',
        'features': ['AC', 'Music', 'GPS'],
        'savings': 74,
      },
      {
        'name': 'Swift, Celerio or equivalent',
        'subtitle': 'Hatchback • AC • 4 Seats',
        'image': 'https://transfer.easemytrip.com/assets/img/wagonr.png',
        'price': 891,
        'originalPrice': 985,
        'rating': 4.8,
        'eta': '5 min',
        'features': ['AC', 'Bluetooth', 'Safety'],
        'savings': 94,
      },
      {
        'name': 'Wagon R or Equivalent',
        'subtitle': 'Compact • AC • 4 Seats',
        'image': 'https://transfer.easemytrip.com/assets/img/xylo.png',
        'price': 905,
        'originalPrice': 965,
        'rating': 4.7,
        'eta': '7 min',
        'features': ['AC', 'USB Port', 'Clean'],
        'savings': 60,
      },
    ];

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final cab = cabs[index];
          return _buildLightCabCard(context, cab, index);
        },
        childCount: cabs.length,
      ),
    );
  }

  Widget _buildLightCabCard(BuildContext context, Map<String, dynamic> cab, int index) {
    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, 30 * (1 - _fadeAnimation.value) * (index + 1)),
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.grey.shade200),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(24),
                  onTap: () {
                    HapticFeedback.mediumImpact();
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation, _) => const CabReviewScreen(),
                        transitionsBuilder: (context, animation, _, child) {
                          return FadeTransition(opacity: animation, child: child);
                        },
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            // **Car Image**
                            Container(
                              width: 120,
                              height: 90,
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.grey.shade50,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Colors.grey.shade200),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  cab['image'],
                                  fit: BoxFit.contain,
                                  errorBuilder: (context, error, stackTrace) =>
                                      Icon(Icons.directions_car, 
                                           color: Colors.grey.shade400, size: 50),
                                ),
                              ),
                            ),
                            
                            const SizedBox(width: 20),
                            
                            // **Car Details**
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              cab['name'],
                                              style: GoogleFonts.poppins(
                                                color: Colors.black87,
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            Text(
                                              cab['subtitle'],
                                              style: GoogleFonts.poppins(
                                                color: Colors.grey.shade600,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      // **Rating & ETA**
                                      Column(
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 8, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: Colors.amber.withOpacity(0.1),
                                              borderRadius: BorderRadius.circular(8),
                                              border: Border.all(color: Colors.amber.shade300),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(Icons.star, 
                                                     color: Colors.amber.shade600, size: 14),
                                                const SizedBox(width: 2),
                                                Text(
                                                  '${cab['rating']}',
                                                  style: GoogleFonts.poppins(
                                                    color: Colors.amber.shade700,
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            'ETA ${cab['eta']}',
                                            style: GoogleFonts.poppins(
                                              color: Colors.green.shade600,
                                              fontSize: 10,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  
                                  const SizedBox(height: 12),
                                  
                                  // **Feature Tags**
                                  Wrap(
                                    spacing: 6,
                                    runSpacing: 4,
                                    children: (cab['features'] as List<String>)
                                        .map((feature) => Container(
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 8, vertical: 2),
                                              decoration: BoxDecoration(
                                                color: themeColor1.withOpacity(0.1),
                                                borderRadius: BorderRadius.circular(8),
                                                border: Border.all(
                                                  color: themeColor1.withOpacity(0.3),
                                                ),
                                              ),
                                              child: Text(
                                                feature,
                                                style: GoogleFonts.poppins(
                                                  color: themeColor1,
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ))
                                        .toList(),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        
                        const SizedBox(height: 16),
                        Divider(color: Colors.grey.shade200),
                        const SizedBox(height: 16),
                        
                        // **Price Section**
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      '₹${cab['price']}',
                                      style: GoogleFonts.poppins(
                                        color: Colors.black87,
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      '₹${cab['originalPrice']}',
                                      style: GoogleFonts.poppins(
                                        color: Colors.grey.shade500,
                                        fontSize: 14,
                                        decoration: TextDecoration.lineThrough,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(Icons.check_circle, 
                                         color: Colors.green.shade600, size: 14),
                                    const SizedBox(width: 4),
                                    Text(
                                      'TGOCAB Applied • Save ₹${cab['savings']}',
                                      style: GoogleFonts.poppins(
                                        color: Colors.green.shade600,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            
                          //   // **Book Button**
                          //   Container(
                          //     decoration: BoxDecoration(
                          //       gradient: LinearGradient(
                          //         colors: [themeColor1, themeColor2],
                          //       ),
                          //       borderRadius: BorderRadius.circular(16),
                          //       boxShadow: [
                          //         BoxShadow(
                          //           color: themeColor1.withOpacity(0.3),
                          //           blurRadius: 8,
                          //           offset: const Offset(0, 2),
                          //         ),
                          //       ],
                          //     ),
                          //     child: ElevatedButton(
                          //       onPressed: () {
                          //         HapticFeedback.heavyImpact();
                          //       },
                          //       style: ElevatedButton.styleFrom(
                          //         backgroundColor: Colors.transparent,
                          //         shadowColor: Colors.transparent,
                          //         shape: RoundedRectangleBorder(
                          //           borderRadius: BorderRadius.circular(16),
                          //         ),
                          //       ),
                          //       child: Padding(
                          //         padding: const EdgeInsets.symmetric(
                          //             horizontal: 20, vertical: 12),
                          //         child: Text(
                          //           'BOOK NOW',
                          //           style: GoogleFonts.poppins(
                          //             color: Colors.white,
                          //             fontWeight: FontWeight.bold,
                          //             fontSize: 12,
                          //           ),
                          //         ),
                          //       ),
                          //     ),
                          //   ),
                           ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // **Floating Navigation - Light Theme**
  Widget _buildFloatingNavigation(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildNavButton(Icons.filter_alt_outlined, 'Filter', () {}),
          Container(width: 1, height: 24, color: Colors.grey.shade300),
          _buildNavButton(Icons.sort, 'Sort', () {}),
          Container(width: 1, height: 24, color: Colors.grey.shade300),
          _buildNavButton(Icons.map_outlined, 'Map View', () {}),
        ],
      ),
    );
  }

  Widget _buildNavButton(IconData icon, String label, VoidCallback onTap) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: themeColor1, size: 20),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: GoogleFonts.poppins(
                    color: themeColor1,
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
