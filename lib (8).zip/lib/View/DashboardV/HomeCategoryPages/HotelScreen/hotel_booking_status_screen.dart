import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/FlightScreen/common_widget/bottom_sgeets.dart';
import 'package:trip_go/ViewM/HotelVM/hotel_book_view_model.dart';


class HotelBookingStatusScreen extends StatefulWidget {
  final dynamic request;

  const HotelBookingStatusScreen({super.key, required this.request});

  @override
  State<HotelBookingStatusScreen> createState() => _HotelBookingStatusScreenState();
}

class _HotelBookingStatusScreenState extends State<HotelBookingStatusScreen> {
  late HotelBookViewModel vm;

  @override
  void initState() {
    super.initState();
    vm = context.read<HotelBookViewModel>();

    // Trigger the booking API when the screen is initialized
    WidgetsBinding.instance.addPostFrameCallback((_) {
      vm.bookHotel(widget.request);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Consumer<HotelBookViewModel>(
          builder: (_, vm, __) {
            switch (vm.state) {
              case BookingState.loading:
                return const CircularProgressIndicator();

              case BookingState.success:
                return _AnimatedResult(
                  lottiePath: 'assets/animation/Success.json',
                  title: 'Booking Successful',
                  subtitle:
                      'Invoice #: ${vm.response?.data?.bookResult?.invoiceNumber ?? '-'}',
                );

              case BookingState.failure:
                return _AnimatedResult(
                  lottiePath: 'assets/animation/failed.json',
                  title: 'Booking Failed',
                  subtitle: vm.error ?? 'Please try again later',
                );

              default:
                return const SizedBox.shrink();
            }
          },
        ),
      ),
    );
  }
}

class _AnimatedResult extends StatelessWidget {
  final String lottiePath;
  final String title;
  final String subtitle;

  const _AnimatedResult({
    required this.lottiePath,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Lottie.asset(lottiePath, width: 200, repeat: false),
        const SizedBox(height: 24),
        Text(title, style: textTheme.headlineSmall),
        const SizedBox(height: 8),
        Text(
          subtitle,
          style: textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 32),
        GradientButton(text: 'Done', onPressed: ()=>Navigator.pop(context))
        ],
    );
  }
}
