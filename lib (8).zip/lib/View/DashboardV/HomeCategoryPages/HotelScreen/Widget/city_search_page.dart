import 'package:flutter/material.dart';

class CitySearchPage extends StatefulWidget {
  const CitySearchPage({super.key});

  @override
  State<CitySearchPage> createState() => _CitySearchPageState();
}

class _CitySearchPageState extends State<CitySearchPage> {
  final TextEditingController _controller = TextEditingController();

  final List<String> allCities = [
    "delhi", "Pune", "Ahmedabad", "Mumbai", "Bangalore", "Jaipur", "Agra", "Hyderabad",
    "Dubai", "Abu Dhabi", "Singapore", "Bangkok", "Chennai", "Kolkata", "Goa",
    "Shimla", "Manali", "Paris", "London", "New York",
  ];

  final List<String> domesticCities = [
    "delhi", "Pune", "Ahmedabad", "Mumbai", "Bangalore", "Jaipur", "Agra", "Hyderabad"
  ];

  final List<String> internationalCities = [
    "Dubai", "Abu Dhabi", "Singapore", "Bangkok"
  ];

  List<String> filteredCities = [];

  void _filterCities(String query) {
    setState(() {
      filteredCities = query.isEmpty
          ? []
          : allCities
              .where((city) => city.toLowerCase().contains(query.toLowerCase()))
              .toList();
    });
  }

  Widget _buildCityChip(String name) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          side: const BorderSide(color: Color(0xFF1B499F)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        onPressed: () {
          Navigator.pop(context, name);
        },
        child: Text(
          name,
          style: const TextStyle(
            color: Color(0xFF1B499F),
            fontFamily: 'poppins',
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF7FF),
      body: Column(
        children: [
          // Top blue area with elevated white text field
          Container(
            width: double.infinity,
            color: const Color(0xFF1B499F),
            padding: const EdgeInsets.only(left: 12, right: 12, top: 40, bottom: 16),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(6),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  const Icon(Icons.location_on, color: Color(0xFF1B499F)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      onChanged: _filterCities,
                      style: const TextStyle(color: Colors.black),
                      decoration: const InputDecoration(
                        hintText: "Enter City/Location/Hotel Name",
                        hintStyle: TextStyle(color: Colors.black54),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Content section
          Expanded(
            child: filteredCities.isNotEmpty
                ? ListView.builder(
                    itemCount: filteredCities.length,
                    itemBuilder: (_, index) {
                      return ListTile(
                        title: Text(filteredCities[index]),
                        onTap: () {
                          Navigator.pop(context, filteredCities[index]);
                        },
                      );
                    },
                  )
                : SingleChildScrollView(
                    padding: const EdgeInsets.all(12),
                    child: Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      color: Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Popular Search In Domestic",
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                                fontFamily: 'poppins',
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Wrap(
                              children: domesticCities.map(_buildCityChip).toList(),
                            ),
                            const Divider(height: 30),
                            const Text(
                              "Popular Search In International",
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                                fontFamily: 'poppins',
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Wrap(
                              children: internationalCities.map(_buildCityChip).toList(),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
