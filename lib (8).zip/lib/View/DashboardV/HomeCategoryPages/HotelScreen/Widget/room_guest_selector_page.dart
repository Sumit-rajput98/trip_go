import 'package:flutter/material.dart';

class RoomGuestSelectorPage extends StatefulWidget {
  const RoomGuestSelectorPage({super.key});

  @override
  State<RoomGuestSelectorPage> createState() => _RoomGuestSelectorPageState();
}
class _RoomGuestSelectorPageState extends State<RoomGuestSelectorPage> {
  List<Map<String, int>> rooms = [
    {'adult': 2, 'child': 0},
  ];

  List<List<int?>> childAges = [
    [],
  ];

  void _addRoom() {
    setState(() {
      rooms.add({'adult': 2, 'child': 0});
      childAges.add([]);
    });
  }

  void _removeRoom(int index) {
    if (rooms.length > 1) {
      setState(() {
        rooms.removeAt(index);
        childAges.removeAt(index);
      });
    }
  }

  void _updateGuest(int roomIndex, String type, bool increment) {
    setState(() {
      final current = rooms[roomIndex][type]!;
      if (increment) {
        rooms[roomIndex][type] = current + 1;
        if (type == 'child') {
          childAges[roomIndex].add(null); // Add a new null age slot
        }
      } else {
        if ((type == 'adult' && current > 1) || (type == 'child' && current > 0)) {
          rooms[roomIndex][type] = current - 1;
          if (type == 'child' && childAges[roomIndex].isNotEmpty) {
            childAges[roomIndex].removeLast(); // Remove last child age
          }
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    int totalGuests = rooms.fold(
      0,
      (sum, room) => sum + room['adult']! + room['child']!,
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(
          '$totalGuests Persons in ${rooms.length} Room${rooms.length > 1 ? 's' : ''}',
          style: const TextStyle(
            fontFamily: 'poppins',
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        leading: const BackButton(),
        backgroundColor: const Color(0xFF1B499F),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (int i = 0; i < rooms.length; i++) ...[
            Text("Room ${i + 1}",
                style: const TextStyle(
                    fontWeight: FontWeight.w600, fontSize: 14, fontFamily: 'poppins')),
            const SizedBox(height: 8),

            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: const [
                Chip(label: Text("Guest", style: TextStyle(fontSize: 11))),
              ],
            ),
            const SizedBox(height: 12),

            _guestCounterRow(i, 'Adult'),
            const SizedBox(height: 12),
            _guestCounterRow(i, 'Child'),

            if (rooms[i]['child']! > 0)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List.generate(
                  rooms[i]['child']!,
                  (index) => Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
  children: [
    Text("Child ${index + 1} Age", style: const TextStyle(fontSize: 14, fontFamily: 'poppins')),
    SizedBox(
      width: 80,
      child: DropdownButtonFormField<int>(
        value: childAges[i].length > index && childAges[i][index] != null
            ? childAges[i][index]
            : 1,
        decoration: const InputDecoration(
          contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          border: OutlineInputBorder(),
          isDense: true,
        ),
        items: List.generate(
          11,
          (a) => DropdownMenuItem(
            value: a + 1,
            child: Text((a + 1).toString()),
          ),
        ),
        onChanged: (value) {
          setState(() {
            childAges[i][index] = value!;
          });
        },
      ),
    ),
  ],
),
  ),
                ),
              ),

            if (i < rooms.length - 1) const Divider(thickness: 1),
          ],

          const SizedBox(height: 12),
          const Divider(thickness: 1),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: _addRoom,
                child: const Text("+ Add Room", style: TextStyle(color: Colors.black87)),
              ),
              if (rooms.length > 1)
                TextButton(
                  onPressed: () => _removeRoom(rooms.length - 1),
                  child: const Text("- Remove Room", style: TextStyle(color: Colors.black87)),
                ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context, {
                    'totalGuests': totalGuests,
                    'rooms': rooms.length,
                    'childAges': childAges,
                  });
                },
                child: const Text("Done", style: TextStyle(color: Colors.black87)),
              ),
            ],
          ),
          const Divider(thickness: 1),
        ],
      ),
    );
  }

  Widget _guestCounterRow(int roomIndex, String type) {
    final key = type.toLowerCase();
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(type, style: const TextStyle(fontSize: 16, fontFamily: 'poppins')),
        Row(
          children: [
            _circleIconButton(
              Icons.remove,
              () => _updateGuest(roomIndex, key, false),
            ),
            const SizedBox(width: 12),
            Text(
              '${rooms[roomIndex][key]}',
              style: const TextStyle(fontSize: 16, fontFamily: 'poppins'),
            ),
            const SizedBox(width: 12),
            _circleIconButton(
              Icons.add,
              () => _updateGuest(roomIndex, key, true),
            ),
          ],
        ),
      ],
    );
  }

  Widget _circleIconButton(IconData icon, VoidCallback onPressed) {
    return InkWell(
      onTap: onPressed,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: const Color(0xFF1B499F)),
        ),
        child: Icon(icon, size: 20, color: const Color(0xFF1B499F)),
      ),
    );
  }
}
