import 'dart:async';
import 'package:flutter/material.dart';
import 'package:trip_go/Splash/splash_screen.dart';

class LogoIntroScreen extends StatefulWidget {
  const LogoIntroScreen({super.key});

  @override
  State<LogoIntroScreen> createState() => _LogoIntroScreenState();
}

class _LogoIntroScreenState extends State<LogoIntroScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  
  bool navigating = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
   
    _startSequence();
  }

  void _startSequence() async {
    await Future.delayed(const Duration(milliseconds: 900));
    _controller.forward();
    await Future.delayed(const Duration(milliseconds: 700));
    if (mounted && !navigating) {
      navigating = true;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const TripGoSplash()),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Image.asset('assets/images/trip_go.png', height: 90),
      ),
    );
  }
}
