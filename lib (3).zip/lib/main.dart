import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:trip_go/AppManager/Api/api_service/TourService/indian_destination_view_model.dart';
import 'package:trip_go/Model/AccountM/forgot_password_model.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/profile/auth_provider.dart';
import 'package:trip_go/View/DashboardV/bottom_navigation_bar.dart';
import 'package:trip_go/ViewM/AccountVM/edit_profile_view_model.dart';
import 'package:trip_go/ViewM/AccountVM/forgot_password_view_model.dart';
import 'package:trip_go/ViewM/AccountVM/login_otp_view_model.dart';
import 'package:trip_go/ViewM/AccountVM/login_view_model.dart';
import 'package:trip_go/ViewM/AccountVM/register_view_model.dart';
import 'package:trip_go/ViewM/AccountVM/user_view_model.dart';
import 'package:trip_go/ViewM/AccountVM/validate_otp_view_model.dart';
import 'package:trip_go/ViewM/FlightVM/create_order_view_model..dart';
import 'package:trip_go/ViewM/FlightVM/fare_rules_view_model.dart';
import 'package:trip_go/ViewM/FlightVM/flight_quote_view_model.dart';
import 'package:trip_go/ViewM/FlightVM/flight_search_view_model.dart';
import 'package:trip_go/ViewM/FlightVM/flight_ssr_lcc_view_model.dart';
import 'package:trip_go/ViewM/Offers/exclusive_offers_view_model.dart';
import 'package:trip_go/ViewM/TourVM/trending_packages_view_model.dart';
import 'View/DashboardV/HomeCategoryPages/FlightScreen/FlightReviewScreen/promo_section/promo_provider.dart';
import 'ViewM/FlightVM/baggage_selection_provider.dart';
import 'ViewM/FlightVM/baggage_selection_round_provider.dart';
import 'ViewM/FlightVM/flight_quote_round_view_model.dart';
import 'ViewM/FlightVM/flight_ssr_lcc_round_view_model.dart';
import 'ViewM/FlightVM/flight_ticket_lcc_view_model.dart';
import 'ViewM/FlightVM/round_trip_flight_search_view_model.dart';
import 'ViewM/FlightVM/seat_selection_provider_round.dart';
import 'ViewM/FlightVM/select_city_view_model.dart';
import 'ViewM/FlightVM/selected_seats_provider.dart';
import 'ViewM/TourVM/category_view_model.dart';
import 'ViewM/TourVM/destinantion_view_model.dart';
import 'ViewM/TourVM/holiday_themes_view_model.dart';
import 'ViewM/TourVM/international_destination_view_model.dart';
import 'ViewM/TourVM/quick_enquiry_view_model.dart';
import 'ViewM/TourVM/subcategory_view_model.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SeatSelectionProvider()),
        ChangeNotifierProvider(create: (_) => SeatSelectionProviderRound()),
        ChangeNotifierProvider(create: (_) => BaggageSelectionProvider()),
        ChangeNotifierProvider(create: (_) => BaggageSelectionRoundProvider()),
        ChangeNotifierProvider(create: (_) => PromoProvider()),
        ChangeNotifierProvider(create: (_) => FlightSearchViewModel()),
        ChangeNotifierProvider(create: (_) => SelectCityViewModel()),
        ChangeNotifierProvider(create: (_) => FlightQuoteViewModel()),
        ChangeNotifierProvider(create: (_) => FlightQuoteRoundViewModel()),
        ChangeNotifierProvider(create: (_) => RoundTripFlightSearchViewModel()),
        ChangeNotifierProvider(create: (_) => FareRulesViewModel()),
        ChangeNotifierProvider(create: (_) => FlightSsrLccViewModel()),
        ChangeNotifierProvider(create: (_) => FlightSsrLccRoundViewModel()),
        ChangeNotifierProvider(create: (_) => FlightTicketLccViewModel()),
        ChangeNotifierProvider(create: (_) => TrendingPackagesViewModel()),
        ChangeNotifierProvider(create: (_) => IndianDestinationViewModel()),
        ChangeNotifierProvider(create: (_) => InternationalDestinationViewModel()),
        ChangeNotifierProvider(create: (_) => DestinationViewModel()),
        ChangeNotifierProvider(create: (_) => CategoryViewModel()),
        ChangeNotifierProvider(create: (_) => SubCategoryViewModel()),
        ChangeNotifierProvider(create: (_) => HolidayThemesViewModel()),
        ChangeNotifierProvider(create: (_) => QuickEnquiryViewModel()),
        ChangeNotifierProvider(create: (_) => LoginViewModel()),
        ChangeNotifierProvider(create: (_) => LoginOtpViewModel()),
        ChangeNotifierProvider(create: (_) => ValidateOtpViewModel()),
        ChangeNotifierProvider(create: (_) => RegisterViewModel()),
         ChangeNotifierProvider(create: (_) => ForgotPasswordViewModel()),
          ChangeNotifierProvider(create: (_) => AuthProvider()),
           ChangeNotifierProvider(create: (_) => UserViewModel()),
           ChangeNotifierProvider(create: (_) => EditProfileViewModel()),
           ChangeNotifierProvider(create: (_) => ExclusiveOffersViewModel()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});


  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home:BottomNavigationbar()
    );
  }
}

