import 'package:flutter/material.dart';

class PopularBusDestinatoins extends StatefulWidget {
  const PopularBusDestinatoins({super.key});

  @override
  State<PopularBusDestinatoins> createState() => _PopularHotelDestinationsState();
}

class _PopularHotelDestinationsState extends State<PopularBusDestinatoins> {
  int selectedIndex = -1;

 final List<Map<String, String>> destinations = const [
  {
    "image": "https://www.easemytrip.com/images/hotel-img/mumb-sm.webp",
    "title": "Bangalore",
    "desc": "To: Hyderabad, Mumbai, Goa, Chennai, Pune"
  },
  {
    "image": "https://www.easemytrip.com/images/hotel-img/hyd-sm.webp",
    "title": "Hyderabad",
    "desc": "To: Bangalore, Mumbai, Goa, Chennai, Pune"
  },
  {
    "image": "https://www.easemytrip.com/images/hotel-img/pune-sm.webp",
    "title": "Pune",
    "desc": "To: Bangalore, Goa, Indore, Nagpur, Hyderabad"
  },
  {
    "image": "https://www.easemytrip.com/images/hotel-img/chennai-sm.webp",
    "title": "Chennai",
    "desc": "To: Bangalore, Coimbatore, Hyderabad, Madurai, Tirunelveli"
  },
  {
    "image": "https://images.emtcontent.com/hotel-img/del-sm.webp",
    "title": "Delhi",
    "desc": "To: Manali, Jaipur, Amritsar, Lucknow, Shimla"
  },
];


  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 15),
            child: Center(
              child: Text(
                "Popular Bus Routes",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'poppins',
                ),
              ),
            ),
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: destinations.length,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemBuilder: (context, index) {
            final item = destinations[index];
            final isSelected = selectedIndex == index;

            return GestureDetector(
              onTap: () {
                setState(() {
                  selectedIndex = index;
                });
              },
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFCCCBFF)),
                  gradient: isSelected
                      ? const LinearGradient(
                    begin: Alignment.bottomLeft,
                    end: Alignment.topRight,
                    colors: [Colors.white, Color(0xFFDDE8FE)],
                  )
                      : null,
                  color: isSelected ? null : Colors.white,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        item['image']!,
                        width: 70,
                        height: 70,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item['title']!,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'poppins',
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            item['desc']!,
                            style: const TextStyle(
                              fontSize: 12,
                              fontFamily: 'poppins',
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
