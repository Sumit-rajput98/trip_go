import 'package:flutter/material.dart';
import 'package:trip_go/View/Widgets/Drawer/custom_drawer.dart';

class BusCard extends StatelessWidget {
  final String name;
  final String departure;
  final String arrival;
  final String duration;
  final String rating;
  final String price;
  final List<String> features; // e.g., ["WiFi", "Water Bottle", "Blanket"]

  const BusCard({
    super.key,
    required this.name,
    required this.departure,
    required this.arrival,
    required this.duration,
    required this.rating,
    required this.price,
    this.features = const [],
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Top Card Section
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(12),
              topRight: Radius.circular(12),
            ),
            color: Colors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.red.shade50,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      "Recommended",
                      style: TextStyle(
                        fontSize: 12,
                        fontFamily: 'poppins',
                        fontWeight: FontWeight.w500,
                        color: Colors.red,
                      ),
                    ),
                  ),

                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Starting From",
                        style: const TextStyle(
                          fontSize: 12,
                          fontFamily: 'poppins',
                          // fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      Text(
                        "$price",
                        style: const TextStyle(
                          fontSize: 14,
                          fontFamily: 'poppins',
                          fontWeight: FontWeight.bold,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 8),

              Text(
                name,
                style: const TextStyle(
                  fontSize: 16,
                  fontFamily: 'poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 4),

              Row(
                children: [
                  const Text(
                    "A/C Seater • ",
                    style: TextStyle(
                      fontSize: 12,
                      fontFamily: 'poppins',
                      color: Colors.black54,
                    ),
                  ),
                  const Icon(Icons.star, size: 14, color: Colors.green),
                  const SizedBox(width: 4),
                  Text(
                    rating,
                    style: const TextStyle(
                      fontSize: 12,
                      fontFamily: 'poppins',
                      color: Colors.green,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    departure,
                    style: const TextStyle(
                      fontSize: 14,
                      fontFamily: 'poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    duration,
                    style: const TextStyle(
                      fontSize: 12,
                      fontFamily: 'poppins',
                      color: Colors.grey,
                    ),
                  ),
                  Text(
                    arrival,
                    style: const TextStyle(
                      fontSize: 14,
                      fontFamily: 'poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Divider(),

              Row(
                children: [
                  const Icon(Icons.event_seat, size: 18, color: Colors.black54),
                  const SizedBox(width: 8),
                  const Icon(Icons.exit_to_app, size: 18, color: Colors.black54),
                  const SizedBox(width: 8),
                  const Icon(Icons.ac_unit, size: 18, color: Colors.black54),
                  const SizedBox(width: 8),
                  const Text(
                    "2+",
                    style: TextStyle(
                      fontSize: 12,
                      fontFamily: 'poppins',
                      color: Colors.black87,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    "Live Tracking",
                    style: TextStyle(
                      fontSize: 12,
                      fontFamily: 'poppins',
                      color: constants.themeColor1,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),

        // Extended Features Section
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(12),
              bottomRight: Radius.circular(12),
            ),
            color: Colors.grey.shade50,
          ),
          child: Wrap(
            spacing: 10,
            runSpacing: 8,
            children: features.map((feature) {
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.circle, size: 8, color: constants.themeColor1),
                  const SizedBox(width: 4),
                  Text(
                    feature,
                    style: const TextStyle(
                      fontSize: 9,
                      fontFamily: 'poppins',
                      color: Colors.black87,
                    ),
                  ),
                ],
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
