import 'package:flutter/material.dart';

class MultiCityTravellersDetail extends StatefulWidget {
  const MultiCityTravellersDetail({super.key});

  @override
  State<MultiCityTravellersDetail> createState() => _MultiCityTravellersDetailState();
}

class _MultiCityTravellersDetailState extends State<MultiCityTravellersDetail> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
