import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SearchCabCityView extends StatefulWidget {
  const SearchCabCityView({super.key});

  @override
  State<SearchCabCityView> createState() => _SearchCabCityViewState();
}

class _SearchCabCityViewState extends State<SearchCabCityView> {
  final TextEditingController _searchController = TextEditingController();

  final List<Map<String, String>> allCities = [
    {'city': 'Delhi', 'state': 'Delhi', 'code': 'DEL'},
    {'city': 'Mumbai', 'state': 'Maharashtra', 'code': 'BOM'},
    {'city': 'Bangalore', 'state': 'Karnataka', 'code': 'BLR'},
    {'city': 'Hyderabad', 'state': 'Telangana', 'code': 'HYD'},
    {'city': 'Chennai', 'state': 'Tamil Nadu', 'code': 'MAA'},
    {'city': 'Pune', 'state': 'Maharashtra', 'code': 'PNQ'},
    {'city': 'Goa', 'state': 'Goa', 'code': 'GOI'},
    {'city': 'Jaipur', 'state': 'Rajasthan', 'code': 'JAI'},
    {'city': 'Kolkata', 'state': 'West Bengal', 'code': 'CCU'},
    {'city': 'Lucknow', 'state': 'Uttar Pradesh', 'code': 'LKO'},
    {'city': 'Shimla', 'state': 'Himachal Pradesh', 'code': 'SIM'},
    {'city': 'Manali', 'state': 'Himachal Pradesh', 'code': 'MAN'},
    {'city': 'Amritsar', 'state': 'Punjab', 'code': 'ATQ'},
    {'city': 'Chandigarh', 'state': 'Punjab', 'code': 'IXC'},
    {'city': 'Bhopal', 'state': 'Madhya Pradesh', 'code': 'BHO'},
    {'city': 'Indore', 'state': 'Madhya Pradesh', 'code': 'IDR'},
    {'city': 'Nagpur', 'state': 'Maharashtra', 'code': 'NAG'},
    {'city': 'Coimbatore', 'state': 'Tamil Nadu', 'code': 'CJB'},
    {'city': 'Tirupati', 'state': 'Andhra Pradesh', 'code': 'TIR'},
    {'city': 'Patna', 'state': 'Bihar', 'code': 'PAT'},
  ];

  List<Map<String, String>> filteredCities = [];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_filterCities);
  }

  void _filterCities() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        filteredCities = [];
      } else {
        filteredCities = allCities.where((city) {
          return (city['city']!.toLowerCase().contains(query) ||
              city['state']!.toLowerCase().contains(query));
        }).toList();
      }
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          /// Header + Search Field
          Container(
            padding: const EdgeInsets.only(top: 50, left: 16, right: 16, bottom: 24),
            decoration: const BoxDecoration(
              color: Color(0xFF2d3290), // your theme header color
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Back + Title
                Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "Select Cab Location",
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                /// Search Field
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    hintText: 'Enter city or airport',
                    hintStyle: GoogleFonts.poppins(fontSize: 14, color: Colors.grey),
                    prefixIcon: const Icon(Icons.search, color: Colors.grey),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ],
            ),
          ),

          /// City List
          if (_searchController.text.isNotEmpty)
            Expanded(
              child: ListView.builder(
                itemCount: filteredCities.length,
                itemBuilder: (context, index) {
                  final city = filteredCities[index];
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    title: Text(
                      "${city['city']}, ${city['state']}",
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                      ),
                    ),
                    subtitle: Text(
                      city['state']!,
                      style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey),
                    ),
                    trailing: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade400,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        city['code']!,
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    onTap: () => Navigator.pop(context, city),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
