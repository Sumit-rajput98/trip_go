import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'hotel_meta_section.dart';
import 'hotel_title_section.dart';
import 'hotel_detail_page.dart'; // for themeColor1

class HotelInfoCard extends StatelessWidget {
  final int selectedTab;
  final List<String> tabs;
  final Function(int) onTabChange;

  const HotelInfoCard({
    super.key,
    required this.selectedTab,
    required this.onTabChange,
    required this.tabs,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: Colors.black12, blurRadius: 8, offset: Offset(0, 2)),
        ],
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const HotelTitleSection(),
            const SizedBox(height: 20),
            const HotelMetaSection(),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      height: 46,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: themeColor1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(tabs.length, (index) {
          final isSelected = index == selectedTab;
          return GestureDetector(
            onTap: () => onTabChange(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding:
                  const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
              decoration: BoxDecoration(
                color: isSelected ? themeColor1 : Colors.transparent,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Text(
                tabs[index],
                style: GoogleFonts.poppins(
                  color: isSelected ? Colors.white : themeColor1,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildTabContent() {
    if (selectedTab == 0) {
      return const Text("Rooms content goes here...",
          style: TextStyle(fontSize: 16));
    } else if (selectedTab == 1) {
      return const Text("Overview content goes here...",
          style: TextStyle(fontSize: 16));
    } else {
      return const Text("Details content goes here...",
          style: TextStyle(fontSize: 16));
    }
  }
}
