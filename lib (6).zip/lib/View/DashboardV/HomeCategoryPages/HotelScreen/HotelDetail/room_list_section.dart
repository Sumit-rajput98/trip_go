import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'hotel_detail_page.dart';

class RoomListSection extends StatefulWidget {
  const RoomListSection({super.key});

  @override
  State<RoomListSection> createState() => _RoomListSectionState();
}

class _RoomListSectionState extends State<RoomListSection> {
  int _selectedRoomIndex = 0;
  int _selectedOptionIndex = 0;

  final List<Map<String, dynamic>> _rooms = [
    {
      "name": "Executive Room",
      "image": "https://media.easemytrip.com/media/Hotel/SHL-18112610137123/Hotel/Hotelpt5gts.png",
      "details": "• 2 single beds\n• 301 Sq Ft. • 28 Sq.m.\n• City View",
      "options": [
        {"title": "Room Without Breakfast", "desc": "Breakfast not included", "price": "6,410", "oldPrice": "10,422", "tax": "795"},
        {"title": "Room With Breakfast", "desc": "Bed and Breakfast", "price": "7,269", "oldPrice": "11,478", "tax": "1352"},
      ]
    },
    {
      "name": "Deluxe Room",
      "image": "https://media.easemytrip.com/media/Hotel/SHL-18112610137123/Hotel/HotelibPZDW.png",
      "details": "• Double\n• 256 Sq Ft.\n• 24 Sq.m.\n• City View",
      "options": [
        {"title": "Room Without Breakfast", "desc": "Breakfast not included", "price": "7,765", "oldPrice": "12,622", "tax": "1,110"},
        {"title": "Room With Breakfast", "desc": "Bed and Breakfast", "price": "8,325", "oldPrice": "13,410", "tax": "1,255"},
      ]
    },
    {
      "name": "Executive Suite",
      "image": "https://media.easemytrip.com/media/Hotel/SHL-18112610137123/Hotel/Hotel6Lu3DU.png",
      "details": "• King Bed\n• 500 Sq Ft.\n• 46 Sq.m.\n• Park View",
      "options": [
        // {"title": "Room Without Breakfast", "desc": "Breakfast not included", "price": "9,540", "oldPrice": "15,320", "tax": "1,500"},
        {"title": "Room With Breakfast", "desc": "Bed and Breakfast", "price": "10,120", "oldPrice": "16,250", "tax": "1,670"},
      ]
    },
    {
      "name": "Club Room",
      "image": "https://media.easemytrip.com/media/Hotel/SHL-18112610137123/Hotel/Hotelpt5gts.png",
      "details": "• 1 Queen, 1 Single\n• 600 Sq Ft.\n• 55 Sq.m.\n• Garden View",
      "options": [
        {"title": "Room Without Breakfast", "desc": "Breakfast not included", "price": "11,200", "oldPrice": "17,400", "tax": "1,850"},
        {"title": "Room With Breakfast", "desc": "Bed and Breakfast", "price": "12,050", "oldPrice": "18,990", "tax": "2,100"},
      ]
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(_rooms.length, (roomIndex) => _buildRoomCard(roomIndex)),
    );
  }

  Widget _buildRoomCard(int roomIndex) {
    final room = _rooms[roomIndex];
    final options = room["options"];
    final isCouponApplied = false;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  room['image'],
                  width: 80,
                  height: 80,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(room['name'], style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text(room['details'], style: GoogleFonts.poppins(fontSize: 12)),
                    const SizedBox(height: 4),
                    Text("View More Details", style: GoogleFonts.poppins(fontSize: 12, color: themeColor1)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...List.generate(options.length, (optIndex) {
            final opt = options[optIndex];
            return _buildRateOption(
              isSelected: (_selectedRoomIndex == roomIndex && _selectedOptionIndex == optIndex),
              title: opt['title'],
              price: opt['price'],
              oldPrice: opt['oldPrice'],
              tax: opt['tax'],
              desc: opt['desc'],
              onTap: () {
                setState(() {
                  _selectedRoomIndex = roomIndex;
                  _selectedOptionIndex = optIndex;
                });
              },
            );
          }),
          if (isCouponApplied)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Text("EMTHOTELS Applied",
                    style: GoogleFonts.poppins(color: Colors.white, fontSize: 12)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildRateOption({
    required bool isSelected,
    required String title,
    required String price,
    required String oldPrice,
    required String tax,
    required String desc,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Row(
        children: [
          Radio(
            value: true,
            groupValue: isSelected,
            onChanged: (_) => onTap(),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: GoogleFonts.poppins(fontWeight: FontWeight.w500)),
                Text("\u2713 $desc", style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[700])),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text("\u20B9 $oldPrice",
                  style: GoogleFonts.poppins(
                      decoration: TextDecoration.lineThrough,
                      fontSize: 12,
                      color: Colors.grey)),
              Text("\u20B9 $price", style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w700)),
              Text("+ \u20B9 $tax Taxes & Fees", style: GoogleFonts.poppins(fontSize: 10)),
              Text("Per night", style: GoogleFonts.poppins(fontSize: 10)),
            ],
          )
        ],
      ),
    );
  }
}
