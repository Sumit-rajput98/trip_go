import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/FlightScreen/common_widget/bottom_bar.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/HotelDetail/guest_review_section.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/HotelDetail/hotel_detail_tab.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/HotelDetail/hotel_overview_screen.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/hotel_review_screen.dart';
import 'hotel_info_card.dart';
import 'room_list_section.dart'; // 👈 Your extracted rooms tab widget

const themeColor1 = Color(0xff1B499F);
const themeColor2 = Color(0xffF73130);

class HotelDetailPage extends StatefulWidget {
  const HotelDetailPage({super.key});

  @override
  State<HotelDetailPage> createState() => _HotelDetailPageState();
}

class _HotelDetailPageState extends State<HotelDetailPage> {
  final _pageController = PageController();
  int _selectedTab = 0;

  final List<String> _tabs = ['Rooms', 'Overview', 'Details'];
  final List<String> _images = [
    'https://media.easemytrip.com/media/Hotel/SHL-18112610137123/Hotel/Hotelpt5gts.png',
    'https://media.easemytrip.com/media/Hotel/SHL-18112610137123/Hotel/HotelibPZDW.png',
    'https://media.easemytrip.com/media/Hotel/SHL-18112610137123/Hotel/Hotel6Lu3DU.png'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      bottomNavigationBar: buildBottomBar(context, (){
        Navigator.push(context, MaterialPageRoute(builder:(context)=>HotelReviewScreen()));
      },
      price: 6410
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                  Container(
          height: 280,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black45,
                Colors.transparent,
                Colors.transparent,
                Colors.black26,
              ],
            ),
          ),
        ),
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(10)),
                  child: SizedBox(
                    height: 280,
                    width: double.infinity,
                    child: PageView.builder(
                      controller: _pageController,
                      itemCount: _images.length,
                      itemBuilder: (context, index) {
                        return Image.network(
                          _images[index],
                          fit: BoxFit.cover,
                          width: double.infinity,
                        );
                      },
                    ),
                  ),
                ),

              
                Positioned(
                  top: 40,
                  left: 16,
                  right: 16,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.arrow_back_ios, color: Colors.white, size: 18),
                          const SizedBox(width: 8),
                          Text(
                            "New Delhi, India",
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                      const Icon(Icons.share_outlined, color: Colors.white),
                    ],
                  ),
                ),
                Positioned(
                  bottom: 25,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: SmoothPageIndicator(
                      controller: _pageController,
                      count: _images.length,
                      effect: const WormEffect(
                        dotColor: Colors.white70,
                        activeDotColor: Colors.white,
                        dotHeight: 8,
                        dotWidth: 8,
                      ),
                    ),
                  ),
                )
              ],
            ),

            // Hotel Info Card
            Transform.translate(
              offset: const Offset(0, -20),
              child: HotelInfoCard(
                selectedTab: _selectedTab,
                onTabChange: (index) => setState(() => _selectedTab = index),
                tabs: _tabs,
              ),
            ),

            const SizedBox(height: 12),

            // Tab Bar (outside HotelInfoCard)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _buildTabs(),
            ),

            const SizedBox(height: 12),

            // Tab Content
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  _buildTabContent(),
                  GuestReviewSection(),
                ],
              ),
            ),

            const SizedBox(height: 30), // space below
          ],
        ),
        
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      height: 46,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: themeColor1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(_tabs.length, (index) {
          final isSelected = index == _selectedTab;
          return GestureDetector(
            onTap: () => setState(() => _selectedTab = index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
              decoration: BoxDecoration(
                color: isSelected ? themeColor1 : Colors.transparent,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Text(
                _tabs[index],
                style: GoogleFonts.poppins(
                  color: isSelected ? Colors.white : themeColor1,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildTabContent() {
    if (_selectedTab == 0) {
      return Column(
  children: const [
    RoomListSection(),
    
  ],
)
;
    } else if (_selectedTab == 1) {
      return HotelOverviewScreen();
    } else {
      return HotelDetailsScreen();
    }
  }

  Widget _buildPlaceholder(String text) {
    return Text(
      text,
      style: GoogleFonts.poppins(fontSize: 16),
    );
  }
}
