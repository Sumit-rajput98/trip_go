import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/FlightScreen/FlightWidgets/gst_bottom_sheet.dart';
import 'package:trip_go/View/DashboardV/HomeCategoryPages/HotelScreen/hotel_promo_section.dart';
import 'package:trip_go/constants.dart';

class HotelReviewScreen extends StatefulWidget {
  const HotelReviewScreen({super.key});

  @override
  State<HotelReviewScreen> createState() => _HotelReviewScreenState();
}

class _HotelReviewScreenState extends State<HotelReviewScreen> {
  bool isChecked = false;
  bool isCheckedGst = false;
  String? errorMessage;
  String? emailError;
  String? phoneError;
  String? countErrorMessage;
  String? companyName;
  String? regNo;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Container(
              height: 130,
              decoration: const BoxDecoration(
                color: Color(0xFF341f97),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(28),
                  bottomRight: Radius.circular(28),
                ),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 36),
              alignment: Alignment.topLeft,
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 16),
                  Text(
                    "Hotel Review",
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 90, 16, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHotelCard(),
                  const SizedBox(height: 12),
                  _buildPriceBreakupCard(),
                  const SizedBox(height: 12),
                  _buildTravellerDetailsCard(),
                  const SizedBox(height: 12),
                  HotelPromoSection(),
                  const SizedBox(height: 12),
                  Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 0),
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.white,
                                border: Border.all(color: Colors.grey.withOpacity(.4)),
                              ),
                              child: Row(
                                children: [
                                  Checkbox(
                                    value: isCheckedGst,
                                    onChanged: (val) async {
                                      setState(() {
                                        isCheckedGst = val!;
                                      });
                                      if (val == true) {
                                        setState(() {
                                          isCheckedGst = val!;
                                        });
                                        final result = await showModalBottomSheet<Map<String, String>>(
                                          context: context,
                                          isScrollControlled: true,
                                          shape: const RoundedRectangleBorder(
                                            borderRadius: BorderRadius.vertical(top: Radius.circular(5)),
                                          ),
                                          builder: (context) => const Padding(
                                            padding: EdgeInsets.only(bottom: 20, top: 20, left: 16, right: 16),
                                            child: GstBottomSheet(),
                                          ),
                                        );
            
                                        if (result != null) {
                                          final companyName = result['companyName'];
                                          final regNo = result['registrationNo'];
            
                                          print('Company Name: $companyName');
                                          print('Registration No.: $regNo');
                                        }
                                      }
                                    },
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text("Use GST for this booking (OPTIONAL)", style:GoogleFonts.poppins(
                                            fontSize: 13,
                                            color: Colors.black,
                                            fontWeight: FontWeight.w700
                                        ),),
                                        Text("To claim credit of GST charged by airlines/TripGo, please enter your company's GST number.",style:  GoogleFonts.poppins(
                                          fontSize: 13,
                                          color: Colors.grey.shade600,
                                        ),)
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Checkbox(
                                      value: isChecked,
                                      onChanged: (val) {
                                        setState(() {
                                          isChecked = val!;
                                        });
                                      },
                                    ),
                                    RichText(
                                      text: TextSpan(
                                        style: GoogleFonts.poppins(color: Colors.black),
                                        children: [
                                          const TextSpan(text: "I Accept "),
                                          TextSpan(
                                            text: "T&C ",
                                            style: const TextStyle(color: Colors.blue),
                                          ),
                                          const TextSpan(text: "and "),
                                          TextSpan(
                                            text: "Privacy Policy",
                                            style: const TextStyle(color: Colors.blue),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                if (errorMessage != null)
                                  Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 10),
                                    child: Text(
                                      errorMessage!,
                                      style: const TextStyle(color: Colors.red, fontSize: 14, fontFamily: 'poppins'),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
     );
  }

 Widget _buildHotelCard() {
  return Container(
    padding: const EdgeInsets.all(14),
    decoration: _boxDecoration(),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header: Title and Location
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "The Hans Hotel New Delhi",
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.location_on_outlined, size: 14, color: Colors.grey),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          "15, Barakhamba Rd, Connaught Place, New Delhi",
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: Colors.grey[700],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                'https://media.easemytrip.com/media/Hotel/SHL-18112610137123/Hotel/Hotelpt5gts.png',
                height: 60,
                width: 60,
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // Room info
        Text(
          "Executive Room",
          style: GoogleFonts.poppins(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Colors.black,
          ),
        ),
        Text(
          "Breakfast not included",
          style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[700]),
        ),
        const SizedBox(height: 12),

        // Guest info
        Text(
          "Travel Dates & Guests",
          style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 4),
        Text(
          "1 Night 2 Days • 1 Room • 2 Guests",
          style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[700]),
        ),
        const SizedBox(height: 12),

        // Check-in & Check-out Row
        Row(
          children: [
            Expanded(child: _buildCheckTile("Check-In", "28 Jun 2025\n03:00 PM")),
            const SizedBox(width: 8),
            Expanded(child: _buildCheckTile("Check-Out", "29 Jun 2025\n12:00 PM")),
          ],
        ),
        const SizedBox(height: 12),

        // Bottom Links (optional)
        
      ],
    ),
  );
}

  Widget _buildCheckTile(String title, String date) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(10),
        color: Colors.grey[50],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text(date, style: GoogleFonts.poppins(fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildPriceBreakupCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _boxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Price Breakup", style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Text("A detailed breakdown of cost associated with your booking",
              style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[700])),
          const Divider(height: 20),
          _priceRow("Room x 1 Night", "₹ 8,946"),
          _priceRow("Hotel Discount", "- ₹ 2,840"),
          _priceRow("EMT Discount", "- ₹ 721"),
          const Divider(height: 20),
          _priceRow("Price After Discount", "₹ 5,385"),
          _priceRow("Taxes & Fees", "₹ 566"),
          const Divider(height: 20),
          _priceRow("Grand Total", "₹ 5,951", isBold: true),
        ],
      ),
    );
  }

  Widget _priceRow(String title, String amount, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: GoogleFonts.poppins(fontSize: 13, fontWeight: isBold ? FontWeight.w600 : FontWeight.w400)),
          Text(amount, style: GoogleFonts.poppins(fontWeight: isBold ? FontWeight.w600 : FontWeight.w400)),
        ],
      ),
    );
  }

  Widget _buildTravellerDetailsCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _boxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Traveller Details", style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          _inputRow("Title", "First Name (& Middle Name)", isDropdown: true),
          const SizedBox(height: 8),
          _inputField("Last Name"),
          const SizedBox(height: 8),
          _inputField("Email Address", icon: Icons.mail_outline),
          const SizedBox(height: 8),
          _inputField("Phone Number", icon: Icons.phone),
          const SizedBox(height: 6),
          
        ],
      ),
    );
  }

  Widget _inputRow(String dropdownHint, String textHint, {bool isDropdown = false}) {
    return Row(
      children: [
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<String>(
            value: 'Mr.',
            items: ['Mr.', 'Mrs.', 'Ms.'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (_) {},
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          flex: 5,
          child: _inputField(textHint),
        ),
      ],
    );
  }

  Widget _inputField(String hint, {IconData? icon}) {
    return TextFormField(
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: icon != null ? Icon(icon, size: 18) : null,
        hintStyle: GoogleFonts.poppins(fontSize: 13),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Widget _buildPromoCodeCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _boxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.local_offer_outlined, color: Colors.pink),
              const SizedBox(width: 8),
              Text("Offers and Promo Codes", style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
              const Spacer(),
              Text("Remove", style: GoogleFonts.poppins(fontSize: 12, color: Colors.red)),
            ],
          ),
          const Divider(),
          _promoOption("EMTHOTELS", "Get Rs. 721 Off on hotel booking", selected: true),
          _promoOption("PNBEMT", "Get Rs.1201 OFF via Punjab National Bank EMT Credit cards"),
          _promoOption("GRAB20", "Grab 20% instant OFF"),
          _promoOption("HSBCEMI", "No Cost EMI via HSBC Credit Card EMI"),
          const SizedBox(height: 6),
          Text("View More Coupons", style: GoogleFonts.poppins(fontSize: 13, color: Colors.blue)),
        ],
      ),
    );
  }

  Widget _promoOption(String code, String desc, {bool selected = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: selected ? Colors.blue.shade50 : Colors.grey.shade100,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: selected ? Colors.blue : Colors.grey.shade300),
      ),
      child: Row(
        children: [
          Radio(value: selected, groupValue: true, onChanged: (_) {}),
          const SizedBox(width: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(code, style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
              Text(desc, style: GoogleFonts.poppins(fontSize: 12)),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildTermsAndGST() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Checkbox(value: false, onChanged: (_) {}),
            const SizedBox(width: 6),
            Expanded(
              child: Text.rich(
                TextSpan(
                  text: "I Accept ",
                  style: GoogleFonts.poppins(fontSize: 12),
                  children: [
                    TextSpan(
                        text: "T&C",
                        style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.w600)),
                    const TextSpan(text: " and "),
                    TextSpan(
                        text: "Privacy Policy",
                        style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ],
        ),
        Container(
          padding: const EdgeInsets.all(12),
          margin: const EdgeInsets.only(top: 8),
          decoration: BoxDecoration(
            color: Colors.orange.shade50,
            border: Border.all(color: Colors.orange),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Checkbox(value: false, onChanged: (_) {}),
              const SizedBox(width: 6),
              Expanded(
                child: Text("Use GST for this booking (Optional)\nPlease enter your company’s GST number",
                    style: GoogleFonts.poppins(fontSize: 12)),
              )
            ],
          ),
        ),
      ],
    );
  }

  BoxDecoration _boxDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.grey[300]!),
    );
  }
}
