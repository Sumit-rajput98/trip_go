class ApiConstant{
  static String baseUrl = "https://admin.travelsdata.com/";
}